#!/usr/bin/env python3
"""Small outbound-only SecureWatch inventory agent (Python standard library)."""

import argparse
import ipaddress
import json
import os
import platform
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


CONFIG_PATH = Path.home() / ".securewatch-agent.json"


def system_report():
    system = platform.system() or "Unknown"
    os_name = system
    os_version = platform.release() or ""
    if system == "Linux":
        try:
            release = platform.freedesktop_os_release()
            os_name = release.get("PRETTY_NAME") or release.get("NAME") or "Linux"
            os_version = release.get("VERSION_ID") or os_version
        except (AttributeError, OSError):
            pass

    addresses = set()
    try:
        for result in socket.getaddrinfo(socket.gethostname(), None):
            try:
                address = ipaddress.ip_address(result[4][0].split("%", 1)[0])
            except ValueError:
                continue
            if not (address.is_loopback or address.is_unspecified or address.is_multicast):
                addresses.add(str(address))
    except OSError:
        pass

    return {
        "name": socket.gethostname()[:100] or "Unknown host",
        "os_name": os_name[:100],
        "os_version": os_version[:200],
        "architecture": platform.machine()[:50],
        "local_ips": sorted(addresses)[:16],
    }


def validate_server(value):
    parsed = urllib.parse.urlsplit(value.strip())
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname
            or parsed.username or parsed.password or parsed.path not in {"", "/"}
            or parsed.query or parsed.fragment):
        raise ValueError("Server must be an origin such as https://securewatch.example")
    return f"{parsed.scheme}://{parsed.netloc}"


def post_json(url, payload, token=None):
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.loads(response.read(64 * 1024).decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise RuntimeError(f"SecureWatch returned HTTP {error.code}") from None
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        raise RuntimeError(f"Cannot reach SecureWatch ({type(error).__name__})") from None


def save_config(config):
    CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass


def enroll(server, code):
    result = post_json(
        f"{server}/api/agents/enroll",
        {"enrollment_code": code, **system_report()},
    )
    if not result.get("agent_id") or not result.get("api_token"):
        raise RuntimeError("SecureWatch returned an invalid enrollment response")
    config = {"server": server, "agent_id": result["agent_id"], "api_token": result["api_token"]}
    save_config(config)
    print(f"Agent enrolled. Credentials saved in {CONFIG_PATH}")
    return config


def main():
    parser = argparse.ArgumentParser(description="Send system inventory to SecureWatch")
    parser.add_argument("--server", help="SecureWatch origin URL")
    parser.add_argument("--enroll", help="One-time enrollment code")
    parser.add_argument("--interval", type=int, default=60, help="Heartbeat interval in seconds")
    args = parser.parse_args()

    try:
        if args.enroll:
            if not args.server:
                parser.error("--server is required with --enroll")
            config = enroll(validate_server(args.server), args.enroll)
        else:
            if args.server:
                parser.error("--server can only be used with --enroll")
            config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        server = validate_server(config["server"])
        token = config["api_token"]
        if not isinstance(token, str) or not token:
            raise RuntimeError("Agent credentials are invalid")
    except (OSError, ValueError, KeyError, json.JSONDecodeError, RuntimeError) as error:
        parser.exit(1, f"Agent setup failed: {error}\n")

    interval = max(30, min(args.interval, 3600))
    print(f"SecureWatch agent running; heartbeat every {interval}s. Press Ctrl+C to stop.")
    while True:
        try:
            post_json(f"{server}/api/agents/heartbeat", system_report(), token)
        except RuntimeError as error:
            print(f"Heartbeat failed: {error}")
        time.sleep(interval)


if __name__ == "__main__":
    main()
