"""Copy records from the earlier data/securewatch.db without deleting it."""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path

import app


BASE_DIR = Path(__file__).resolve().parent
LEGACY_DB = BASE_DIR / "data" / "securewatch.db"
TARGET_DB = BASE_DIR / "securewatch.db"
BACKUP_DB = BASE_DIR / "securewatch.before-legacy-import.db"


def parse_datetime(value):
    if not value:
        return datetime.utcnow()
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


def findings_count(value: str) -> int:
    try:
        payload = json.loads(value or "{}")
    except (TypeError, json.JSONDecodeError):
        return 0
    if isinstance(payload, list):
        return len(payload)
    if isinstance(payload, dict):
        findings = payload.get("findings")
        if isinstance(findings, list):
            return len(findings)
        try:
            return max(0, int(payload.get("findings_count", 0)))
        except (TypeError, ValueError):
            return 0
    return 0


def make_backup() -> None:
    if BACKUP_DB.exists():
        return
    source = sqlite3.connect(TARGET_DB)
    backup = sqlite3.connect(BACKUP_DB)
    try:
        source.backup(backup)
    finally:
        backup.close()
        source.close()


def main() -> None:
    if not LEGACY_DB.exists():
        print("Legacy database not found; nothing imported.")
        return

    make_backup()
    legacy = sqlite3.connect(LEGACY_DB)
    legacy.row_factory = sqlite3.Row
    db = app.SessionLocal()
    counts = {"users": 0, "scans": 0, "fixes": 0, "audit": 0}
    user_ids: dict[int, int] = {}

    try:
        legacy_tables = {
            row[0]
            for row in legacy.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }

        for row in legacy.execute("SELECT * FROM users") if "users" in legacy_tables else []:
            email = (row["email"] or "").strip().lower()
            if not email:
                continue
            user = db.query(app.User).filter(app.User.email == email).first()
            if not user:
                base_username = re.sub(r"[^a-zA-Z0-9_.-]", "_", email.split("@", 1)[0])[:80]
                if len(base_username) < 3:
                    base_username = f"legacy_{row['id']}"
                username = base_username
                suffix = 1
                while db.query(app.User).filter(app.User.username == username).first():
                    suffix += 1
                    username = f"{base_username[:88]}_{suffix}"

                role = row["role"] if row["role"] in {"owner", "security_admin", "employee"} else "employee"
                user = app.User(
                    username=username,
                    email=email,
                    password_hash=row["password_hash"],
                    role=role,
                    is_active=bool(row["active"]),
                    created_at=parse_datetime(row["created_at"]),
                )
                db.add(user)
                db.flush()
                counts["users"] += 1
            user_ids[row["id"]] = user.id

        if "scans" in legacy_tables:
            for row in legacy.execute("SELECT * FROM scans"):
                kind = "file" if row["kind"] in {"file", "files"} else row["kind"]
                created_at = parse_datetime(row["created"])
                created_by = next(
                    (new_id for old_id, new_id in user_ids.items()
                     if old_id == row.get("user_id")),
                    None,
                ) if "user_id" in row.keys() else None
                if not created_by and row["email"]:
                    owner = db.query(app.User).filter(
                        app.User.email == row["email"].strip().lower()
                    ).first()
                    created_by = owner.id if owner else None

                filename = row["target"] or "Legacy scan"
                existing = db.query(app.Scan).filter(
                    app.Scan.filename == filename,
                    app.Scan.scan_type == kind,
                    app.Scan.created_at == created_at,
                ).first()
                if existing:
                    continue

                status = row["status"]
                if status == "clean":
                    status = "completed"
                db.add(app.Scan(
                    filename=filename,
                    scan_type=kind,
                    status=status,
                    result=row["findings"] or "{}",
                    findings=findings_count(row["findings"]),
                    created_by=created_by,
                    created_at=created_at,
                ))
                counts["scans"] += 1

        if "fixes" in legacy_tables:
            for row in legacy.execute("SELECT * FROM fixes"):
                recommendation = (row["recommendation"] or "").strip()
                title = recommendation[:120] or "Legacy recommendation"
                description = f"Imported recommendation for scan #{row['scan_id']}.\n{recommendation}"
                if row["reviewer"]:
                    description += f"\nLegacy reviewer: {row['reviewer']}"
                existing = db.query(app.Fix).filter(
                    app.Fix.title == title,
                    app.Fix.description == description,
                ).first()
                if existing:
                    continue
                status = "open" if row["status"] == "pending" else "closed"
                db.add(app.Fix(title=title, description=description, status=status))
                counts["fixes"] += 1

        if "audit" in legacy_tables:
            for row in legacy.execute("SELECT * FROM audit"):
                email = (row["email"] or "").strip().lower()
                user = db.query(app.User).filter(app.User.email == email).first() if email else None
                action = str(row["event"] or "legacy_event")[:255]
                details = row["detail"] or ""
                created_at = parse_datetime(row["created"])
                exists = db.query(app.Audit).filter(
                    app.Audit.user_id == (user.id if user else None),
                    app.Audit.action == action,
                    app.Audit.details == details,
                    app.Audit.created_at == created_at,
                ).first()
                if exists:
                    continue
                db.add(app.Audit(
                    user_id=user.id if user else None,
                    action=action,
                    details=details,
                    created_at=created_at,
                ))
                counts["audit"] += 1

        if "audit_events" in legacy_tables:
            for row in legacy.execute("SELECT * FROM audit_events"):
                old_user_id = row["user_id"]
                user_id = user_ids.get(old_user_id)
                action = str(row["action"] or "legacy_event")[:255]
                created_at = parse_datetime(row["created_at"])
                details = "Imported from earlier audit event log"
                exists = db.query(app.Audit).filter(
                    app.Audit.user_id == user_id,
                    app.Audit.action == action,
                    app.Audit.details == details,
                    app.Audit.created_at == created_at,
                ).first()
                if exists:
                    continue
                db.add(app.Audit(
                    user_id=user_id,
                    action=action,
                    details=details,
                    created_at=created_at,
                ))
                counts["audit"] += 1

        db.commit()
        print("Imported records:", counts)
        print("Original database preserved:", LEGACY_DB)
        print("Backup created:", BACKUP_DB)
        print("Legacy hashed invitations were kept in the original database; create a fresh invite in SecureWatch.")
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
        legacy.close()


if __name__ == "__main__":
    main()
