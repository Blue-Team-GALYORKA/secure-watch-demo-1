# SecureWatch

Учебный MVP платформы мониторинга и проверки безопасности. Подробная инструкция на русском находится в [README_RU.md](README_RU.md).

## Запуск на Ubuntu или Kali Linux через Docker Compose

Нужны Docker Engine и Compose plugin. Склонируйте репозиторий и перейдите в каталог проекта:

```bash
git clone https://github.com/Blue-Team-GALYORKA/secure-watch-demo-1.git
cd secure-watch-demo-1
cp .env.example .env
```

В `.env` замените `SECRET_KEY` на случайное значение, например сгенерированное командой:

```bash
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

Оставьте `SECUREWATCH_ADMIN_PASSWORD` пустым для генерации уникального пароля администратора при первом старте. Подготовьте постоянный каталог базы и запустите контейнер:

```bash
mkdir -p data
sudo chown 10001:10001 data
sudo chmod 700 data
docker compose up --build -d
docker compose logs --tail=100 securewatch
```

Первоначальный пароль администратора появится в логе контейнера только при создании аккаунта. Сохраните его в менеджере паролей. Интерфейс будет доступен на http://127.0.0.1:8000. База сохраняется в `data/` и остаётся после `docker compose down`.

Compose привязывает веб-порт к loopback-интерфейсу. Для удалённого доступа настройте HTTPS reverse proxy, установите `COOKIE_SECURE=1` и добавьте его публичное имя в `ALLOWED_HOSTS`; не выставляйте приложение напрямую в интернет.

## Ограничения

Приложение проверяет Origin/Referer для изменяющих запросов, ограничивает допустимые Host и добавляет защитные HTTP-заголовки. Для reverse proxy укажите его имя в `ALLOWED_HOSTS`.

На Linux проверка загруженных файлов использует встроенные эвристики; Microsoft Defender доступен только в поддерживаемой Windows-среде. Сканер не запускает загруженные файлы и не заменяет полноценный антивирус. Это учебный MVP, который требует дальнейшего усиления и аудита перед production-развёртыванием.
