from __future__ import annotations

import ast
import ipaddress
import hashlib
import json
import os
import re
import secrets
import socket
import shutil
import subprocess
import sys
import tempfile
import time
import threading
from collections import deque
import urllib.error
import urllib.parse
import urllib.request

from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

from fastapi import (
    FastAPI,
    Request,
    Form,
    UploadFile,
    File,
    HTTPException,
    Depends,
)
from fastapi.responses import (
    HTMLResponse,
    RedirectResponse,
    JSONResponse,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    Text,
    DateTime,
    Boolean,
    ForeignKey,
    or_,
    update,
)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import (
    declarative_base,
    sessionmaker,
    relationship,
    Session,
)

from pwdlib import PasswordHash


# ============================================================
# CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

if os.name == "posix":
    os.umask(0o077)

TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR = BASE_DIR / "uploads"

TEMPLATES_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"sqlite:///{BASE_DIR / 'securewatch.db'}",
)

SECRET_KEY = os.getenv(
    "SECRET_KEY",
    os.getenv("SESSION_SECRET", ""),
)
if not SECRET_KEY:
    SECRET_KEY = secrets.token_urlsafe(48)
elif len(SECRET_KEY) < 32:
    raise RuntimeError("SECRET_KEY/SESSION_SECRET must be at least 32 characters")

SESSION_MAX_AGE = 60 * 60 * 8
PRIMARY_OWNER_USERNAME = os.getenv("SECUREWATCH_PRIMARY_OWNER", "owner").strip()
ALLOWED_HOSTS = [
    host.strip()
    for host in os.getenv("ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")
    if host.strip()
]
if not ALLOWED_HOSTS:
    ALLOWED_HOSTS = ["localhost", "127.0.0.1"]

try:
    OSINT_REFRESH_INTERVAL_SECONDS = max(
        300,
        int(os.getenv("OSINT_REFRESH_INTERVAL_SECONDS", "3600")),
    )
except ValueError:
    OSINT_REFRESH_INTERVAL_SECONDS = 3600

OSINT_REFRESH_BATCH_SIZE = 10
_osint_refresh_stop = threading.Event()
_osint_refresh_cursor = 0
_osint_refresh_thread = None

password_hasher = PasswordHash.recommended()
_dummy_password_hash = password_hasher.hash(secrets.token_urlsafe(32))
_login_attempts = {}
_login_attempts_lock = threading.Lock()
LOGIN_WINDOW_SECONDS = 10 * 60
LOGIN_MAX_ATTEMPTS = 5


# ============================================================
# DATABASE
# ============================================================

engine_options = {}

if DATABASE_URL.startswith("sqlite"):
    engine_options["connect_args"] = {
        "check_same_thread": False
    }

engine = create_engine(
    DATABASE_URL,
    **engine_options,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

Base = declarative_base()


def get_db():
    db = SessionLocal()

    try:
        yield db
    finally:
        db.close()


# ============================================================
# DATABASE MODELS
# ============================================================

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, index=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(50), default="employee")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Invite(Base):
    __tablename__ = "invites"

    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(100), unique=True, nullable=False)
    role = Column(String(50), default="employee")
    created_by = Column(Integer, ForeignKey("users.id"))
    used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Audit(Base):
    __tablename__ = "audit"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(255), nullable=False)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Scan(Base):
    __tablename__ = "scans"

    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(255), nullable=False)
    scan_type = Column(String(50), default="file")
    status = Column(String(50), default="completed")
    result = Column(Text, nullable=True)
    findings = Column(Integer, default=0)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Fix(Base):
    __tablename__ = "fixes"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(50), default="open")
    created_at = Column(DateTime, default=datetime.utcnow)


class OSINTNode(Base):
    __tablename__ = "osint_nodes"

    id = Column(Integer, primary_key=True, index=True)
    value = Column(String(500), index=True, nullable=False)
    node_type = Column(String(50), nullable=False)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class OSINTEdge(Base):
    __tablename__ = "osint_edges"

    id = Column(Integer, primary_key=True, index=True)
    source_id = Column(Integer, ForeignKey("osint_nodes.id"))
    target_id = Column(Integer, ForeignKey("osint_nodes.id"))
    relationship = Column(String(100), default="related")
    details = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class ConnectedSystem(Base):
    __tablename__ = "connected_systems"

    device_id = Column(String(64), primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    os_name = Column(String(100), nullable=False, default="Unknown OS")
    browser = Column(String(100), nullable=False, default="Unknown browser")
    ip_address = Column(String(45), nullable=False, index=True)
    first_seen = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_seen = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)


class ManagedAgent(Base):
    __tablename__ = "managed_agents"

    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    os_name = Column(String(100), nullable=False)
    os_version = Column(String(200), nullable=False, default="")
    architecture = Column(String(50), nullable=False, default="")
    local_ips = Column(Text, nullable=False, default="[]")
    remote_ip = Column(String(45), nullable=False, default="unknown")
    token_hash = Column(String(64), unique=True, nullable=False, index=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    active = Column(Boolean, default=True, nullable=False)
    enrolled_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_seen = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)


class AgentEnrollment(Base):
    __tablename__ = "agent_enrollments"

    code_hash = Column(String(64), primary_key=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used_at = Column(DateTime, nullable=True)


Base.metadata.create_all(bind=engine)


# ============================================================
# FASTAPI APPLICATION
# ============================================================

app = FastAPI(
    title="SecureWatch",
    description="Security monitoring and OSINT platform",
    version="1.0.0",
)

app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    max_age=SESSION_MAX_AGE,
    same_site="lax",
    https_only=os.getenv("COOKIE_SECURE", "0") == "1",
)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=ALLOWED_HOSTS,
)


CSRF_EXEMPT_PATHS = {
    "/api/agents/enroll",
    "/api/agents/heartbeat",
}
UNSAFE_HTTP_METHODS = {"POST", "PUT", "PATCH", "DELETE"}


@app.middleware("http")
async def security_headers_and_csrf(request: Request, call_next):
    if request.method in UNSAFE_HTTP_METHODS and request.url.path not in CSRF_EXEMPT_PATHS:
        source = request.headers.get("origin") or request.headers.get("referer")
        host = request.headers.get("host", "").lower()
        try:
            source_parts = urllib.parse.urlsplit(source or "")
            source_host = source_parts.netloc.lower()
            origin_is_trusted = (
                source_parts.scheme in {"http", "https"}
                and bool(source_host)
                and source_host == host
            )
        except ValueError:
            origin_is_trusted = False
        if not origin_is_trusted:
            return JSONResponse(status_code=403, content={"detail": "Cross-site request rejected"})

    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Cache-Control", "private, no-store")
    if request.url.scheme == "https":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    return response

app.mount(
    "/static",
    StaticFiles(directory=str(STATIC_DIR)),
    name="static",
)

templates = Jinja2Templates(
    directory=str(TEMPLATES_DIR)
)


# ============================================================
# AUTHENTICATION HELPERS
# ============================================================

def hash_password(password: str) -> str:
    return password_hasher.hash(password)


def verify_password(
    plain_password: str,
    password_hash: str,
) -> bool:
    try:
        return password_hasher.verify(
            plain_password,
            password_hash,
        )
    except Exception:
        return False


def login_attempt_limited(client_key: str, *, record_failure: bool = False, reset: bool = False) -> bool:
    """Small per-process login throttle; use a shared store for multi-worker deployments."""
    now = time.monotonic()
    with _login_attempts_lock:
        expired_before = now - LOGIN_WINDOW_SECONDS
        for key in list(_login_attempts):
            attempts = _login_attempts[key]
            while attempts and attempts[0] <= expired_before:
                attempts.popleft()
            if not attempts:
                _login_attempts.pop(key, None)
        if reset:
            _login_attempts.pop(client_key, None)
            return False
        attempts = _login_attempts.setdefault(client_key, deque())
        if len(attempts) >= LOGIN_MAX_ATTEMPTS:
            return True
        if record_failure:
            attempts.append(now)
        return False


def get_current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> Optional[User]:

    user_id = request.session.get("user_id")

    if not user_id:
        return None

    user = db.query(User).filter(
        User.id == user_id,
        User.is_active.is_(True),
    ).first()

    return user


def require_user(
    request: Request,
    db: Session = Depends(get_db),
) -> User:

    user = get_current_user(request, db)

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Authentication required",
        )

    return user


def require_admin(
    request: Request,
    db: Session = Depends(get_db),
) -> User:

    user = require_user(request, db)

    if user.role not in ("owner", "security_admin"):
        raise HTTPException(
            status_code=403,
            detail="Administrator access required",
        )

    return user


def get_primary_owner(db: Session) -> Optional[User]:
    """Return the configured main owner, falling back to the oldest owner."""
    if PRIMARY_OWNER_USERNAME:
        owner = db.query(User).filter(
            User.username == PRIMARY_OWNER_USERNAME
        ).first()
        if owner:
            return owner
    return db.query(User).filter(
        User.role == "owner"
    ).order_by(User.id.asc()).first()


def log_audit(
    db: Session,
    user_id: Optional[int],
    action: str,
    details: str = "",
):
    record = Audit(
        user_id=user_id,
        action=action,
        details=details,
    )

    db.add(record)
    db.commit()


# ============================================================
# GENERAL ROUTES
# ============================================================

@app.get("/", response_class=HTMLResponse)
def home(
    request: Request,
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)

    if user:
        return RedirectResponse(
            "/dashboard",
            status_code=303,
        )

    return RedirectResponse(
        "/login",
        status_code=303,
    )


@app.get("/health")
def health():
    return {
        "status": "ok",
        "application": "SecureWatch",
        "timestamp": datetime.utcnow().isoformat(),
    }


# ============================================================
# LOGIN
# ============================================================

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={
            "request": request,
            "error": None,
        },
    )


@app.post("/login")
def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    client_key = request.client.host if request.client else "unknown"
    if login_attempt_limited(client_key):
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"request": request, "error": "Too many attempts. Try again in 10 minutes."},
            status_code=429,
            headers={"Retry-After": str(LOGIN_WINDOW_SECONDS)},
        )

    identifier = username.strip()
    user = db.query(User).filter(
        or_(User.username == identifier, User.email == identifier.lower()),
        User.is_active.is_(True),
    ).first()

    candidate_hash = user.password_hash if user else _dummy_password_hash
    password_matches = verify_password(password, candidate_hash)
    if not user or not password_matches:
        login_attempt_limited(client_key, record_failure=True)
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={
                "request": request,
                "error": "Invalid username or password",
            },
            status_code=401,
        )

    request.session.clear()
    request.session["user_id"] = user.id
    login_attempt_limited(client_key, reset=True)

    log_audit(
        db,
        user.id,
        "login",
        "User logged in",
    )

    return RedirectResponse(
        "/dashboard",
        status_code=303,
    )


@app.post("/logout")
def logout(
    request: Request,
    db: Session = Depends(get_db),
):
    user_id = request.session.get("user_id")

    if user_id:
        log_audit(
            db,
            user_id,
            "logout",
            "User logged out",
        )

    request.session.clear()

    return RedirectResponse(
        "/login",
        status_code=303,
    )


# ============================================================
# REGISTRATION
# ============================================================

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="register.html",
        context={
            "request": request,
            "error": None,
            "invite_code": request.query_params.get("invite_code", ""),
        },
    )


@app.post("/register")
def register(
    request: Request,
    username: str = Form(""),
    password: str = Form(...),
    email: str = Form(""),
    invite_code: str = Form(...),
    db: Session = Depends(get_db),
):
    username = username.strip()
    email = email.strip().lower()
    invite_code = invite_code.strip()

    if len(username) < 3 or len(password) < 8:
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={
                "request": request,
                "error": "Username must have at least 3 characters and password at least 8",
                "invite_code": invite_code,
            },
            status_code=400,
        )

    existing = db.query(User).filter(
        User.username == username
    ).first()

    if existing:
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={
                "request": request,
                "error": "Username already exists",
                "invite_code": invite_code,
            },
            status_code=400,
        )

    if email:
        existing_email = db.query(User).filter(
            User.email == email
        ).first()

        if existing_email:
            return templates.TemplateResponse(
                request=request,
                name="register.html",
                context={
                    "request": request,
                    "error": "Email already exists",
                    "invite_code": invite_code,
                },
                status_code=400,
            )

    invite = db.query(Invite).filter(
        Invite.code == invite_code,
        Invite.used.is_(False),
    ).first()

    if not invite:
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={
                "request": request,
                "error": "Приглашение недействительно или уже использовано",
                "invite_code": invite_code,
            },
            status_code=400,
        )

    role = invite.role
    claimed = db.execute(
        update(Invite)
        .where(Invite.id == invite.id, Invite.used.is_(False))
        .values(used=True)
    )
    if claimed.rowcount != 1:
        db.rollback()
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={
                "request": request,
                "error": "Приглашение уже использовано",
                "invite_code": invite_code,
            },
            status_code=400,
        )

    user = User(
        username=username,
        email=email or None,
        password_hash=hash_password(password),
        role=role,
    )

    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return templates.TemplateResponse(
            request=request,
            name="register.html",
            context={
                "request": request,
                "error": "Такое имя пользователя или email уже заняты",
                "invite_code": invite_code,
            },
            status_code=400,
        )
    db.refresh(user)

    log_audit(
        db,
        user.id,
        "register",
        "New account created",
    )

    return RedirectResponse(
        "/login",
        status_code=303,
    )


# ============================================================
# DASHBOARD
# ============================================================

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(
    request: Request,
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)

    if not user:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    all_scans = db.query(Scan).order_by(Scan.created_at.desc()).all()
    scans = all_scans[:10]
    scan_count = len(all_scans)
    clean_scans = sum(1 for scan in all_scans if not (scan.findings or 0))
    finding_scans = sum(1 for scan in all_scans if (scan.findings or 0) > 0)
    error_scans = sum(1 for scan in all_scans if scan.status == "error")
    scan_labels = [scan.created_at.strftime("%Y-%m-%d") for scan in reversed(all_scans[:14])]
    scan_values = [sum(1 for scan in all_scans if scan.created_at.strftime("%Y-%m-%d") == day) for day in scan_labels]

    open_fixes = db.query(Fix).filter(
        Fix.status == "open"
    ).count()

    osint_nodes = db.query(OSINTNode).count()

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "request": request,
            "user": user,
            "scans": scans,
            "scan_count": scan_count,
            "total_scans": scan_count,
            "clean_scans": clean_scans,
            "finding_scans": finding_scans,
            "error_scans": error_scans,
            "scan_labels": scan_labels,
            "scan_values": scan_values,
            "threat_levels": {"high": 0, "medium": 0, "low": 0, "clean": clean_scans},
            "open_fixes": open_fixes,
            "osint_nodes": osint_nodes,
        },
    )


@app.get("/settings", response_class=HTMLResponse)
def settings_page(
    request: Request,
    db: Session = Depends(get_db),
):
    current_user = get_current_user(request, db)
    if not current_user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse(
        request=request,
        name="settings.html",
        context={
            "request": request,
            "user": current_user,
        },
    )


# ============================================================
# USERS MANAGEMENT
# ============================================================

@app.get("/agents", response_class=HTMLResponse)
def agents_page(
    request: Request,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    agents = db.query(ManagedAgent).order_by(
        ManagedAgent.active.desc(), ManagedAgent.last_seen.desc()
    ).all()
    return templates.TemplateResponse(
        request=request,
        name="agents.html",
        context={"request": request, "user": current_user, "agents": agents},
    )


@app.post("/agents/{agent_id}/revoke")
def revoke_agent(
    agent_id: str,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    agent = db.query(ManagedAgent).filter(ManagedAgent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    agent.active = False
    db.commit()
    log_audit(db, current_user.id, "agent_revoked", agent.id)
    return RedirectResponse("/agents", status_code=303)


@app.post("/agents/enrollments")
def create_agent_enrollment(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    code = secrets.token_urlsafe(32)
    expires_at = datetime.utcnow() + timedelta(hours=24)
    db.add(AgentEnrollment(
        code_hash=hashlib.sha256(code.encode("utf-8")).hexdigest(),
        created_by=current_user.id,
        expires_at=expires_at,
    ))
    db.commit()
    log_audit(db, current_user.id, "agent_enrollment_created", "24h")
    return {"code": code, "expires_at": expires_at.isoformat()}

@app.get("/users", response_class=HTMLResponse)
def users_page(
    request: Request,
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)

    if not user:
        return RedirectResponse(
            "/login",
            status_code=303,
        )

    if user.role not in ("owner", "security_admin"):
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    primary_owner = get_primary_owner(db)
    users_query = db.query(User)
    if primary_owner:
        users_query = users_query.filter(User.id != primary_owner.id)
    users = users_query.order_by(User.created_at.desc()).all()

    return templates.TemplateResponse(
        request=request,
        name="users.html",
        context={
            "request": request,
            "user": user,
            "users": users,
        },
    )


@app.post("/users/{user_id}/role")
def update_user_role(
    user_id: int,
    role: str = Form(...),
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    allowed_roles = {"security_admin", "employee"}

    if role not in allowed_roles:
        raise HTTPException(
            status_code=400,
            detail="Invalid role",
        )

    target = db.query(User).filter(
        User.id == user_id
    ).first()

    if not target:
        raise HTTPException(
            status_code=404,
            detail="User not found",
        )

    primary_owner = get_primary_owner(db)
    if primary_owner and target.id == primary_owner.id:
        raise HTTPException(status_code=400, detail="The main account role cannot be changed")

    if target.id == current_user.id and role != "owner":
        raise HTTPException(
            status_code=400,
            detail="You cannot remove your own owner role",
        )

    if target.role == "owner" or role == "owner":
        raise HTTPException(status_code=400, detail="Only the main account can have the owner role")

    target.role = role
    db.commit()

    log_audit(
        db,
        current_user.id,
        "user_role_changed",
        f"User {target.username}: {role}",
    )

    return RedirectResponse(
        "/users",
        status_code=303,
    )


@app.post("/users/{user_id}/disable")
def disable_user(
    user_id: int,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    target = db.query(User).filter(
        User.id == user_id
    ).first()

    if not target:
        raise HTTPException(
            status_code=404,
            detail="User not found",
        )

    primary_owner = get_primary_owner(db)
    if primary_owner and target.id == primary_owner.id:
        raise HTTPException(status_code=400, detail="The main account cannot be disabled")

    if target.role == "owner" and current_user.role != "owner":
        raise HTTPException(status_code=403, detail="Only the owner can disable an owner")

    if target.id == current_user.id:
        raise HTTPException(
            status_code=400,
            detail="You cannot disable your own account",
        )

    target.is_active = False
    db.commit()

    log_audit(
        db,
        current_user.id,
        "user_disabled",
        target.username,
    )

    return RedirectResponse(
        "/users",
        status_code=303,
    )


# ============================================================
# INVITATIONS
# ============================================================

@app.post("/invites/create")
def create_invite(
    role: str = Form("employee"),
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    if role not in {
        "employee",
        "security_admin",
    }:
        raise HTTPException(
            status_code=400,
            detail="Invalid invite role",
        )

    code = secrets.token_urlsafe(18)

    invite = Invite(
        code=code,
        role=role,
        created_by=current_user.id,
    )

    db.add(invite)
    db.commit()

    log_audit(
        db,
        current_user.id,
        "invite_created",
        role,
    )

    return {
        "code": code,
        "role": role,
    }


# ============================================================
# FILE SCANNING
# ============================================================

DANGEROUS_EXTENSIONS = {
    ".exe",
    ".dll",
    ".bat",
    ".cmd",
    ".ps1",
    ".vbs",
    ".js",
    ".scr",
    ".msi",
}


def analyze_file(filename: str, content: bytes) -> dict:
    findings = []

    extension = Path(filename).suffix.lower()

    if extension in DANGEROUS_EXTENSIONS:
        findings.append({
            "severity": "medium",
            "title": "Executable or script file",
            "description": (
                "The file type can execute code. "
                "Verify its origin before opening."
            ),
        })

    if len(content) == 0:
        findings.append({
            "severity": "low",
            "title": "Empty file",
            "description": "The uploaded file is empty.",
        })

    if b"powershell -enc" in content.lower():
        findings.append({
            "severity": "high",
            "title": "Suspicious PowerShell command",
            "description": (
                "An encoded PowerShell command pattern was detected."
            ),
        })

    if b"cmd.exe /c" in content.lower():
        findings.append({
            "severity": "medium",
            "title": "Command execution pattern",
            "description": (
                "A command execution pattern was detected."
            ),
        })

    av_scan = scan_with_microsoft_defender(filename, content)

    return {
        "filename": filename,
        "size": len(content),
        "findings": findings,
        "findings_count": len(findings),
        "antivirus": av_scan,
    }


def scan_with_microsoft_defender(filename: str, content: bytes) -> dict:
    """Scan a temporary copy with Defender when available; never execute the file."""
    program_files = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    program_data = Path(os.environ.get("ProgramData", r"C:\ProgramData"))
    executable = program_files / "Windows Defender" / "MpCmdRun.exe"
    if not executable.is_file():
        platform_dir = program_data / "Microsoft" / "Windows Defender" / "Platform"
        platform_bins = sorted(platform_dir.glob("*\\MpCmdRun.exe"), reverse=True)
        executable = platform_bins[0] if platform_bins else Path(shutil.which("MpCmdRun.exe") or "")
    if not executable.is_file():
        return {"status": "unavailable", "engine": "Microsoft Defender",
                "message": "Microsoft Defender command-line scanner was not found."}

    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(prefix="securewatch-", suffix=Path(filename).suffix[:16], delete=False) as temp_file:
            temp_file.write(content)
            temp_path = Path(temp_file.name)
        proc = subprocess.run(
            [str(executable), "-Scan", "-ScanType", "3", "-File", str(temp_path), "-DisableRemediation"],
            capture_output=True, text=True, timeout=120, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        output = (proc.stdout + "\n" + proc.stderr).strip()
        if proc.returncode == 0:
            return {"status": "clean", "engine": "Microsoft Defender",
                    "message": "No threat was reported by Microsoft Defender."}
        return {"status": "threat_or_error", "engine": "Microsoft Defender",
                "return_code": proc.returncode,
                "message": output[-2000:] or "Defender reported a threat or scan error; review Windows Security for details."}
    except subprocess.TimeoutExpired:
        return {"status": "error", "engine": "Microsoft Defender", "message": "Defender scan timed out."}
    except OSError as exc:
        return {"status": "error", "engine": "Microsoft Defender",
                "message": f"Defender scan could not start ({type(exc).__name__})."}
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def iter_site_audit_checks():
    """Run bounded, local-only source checks; never execute scanned project code."""
    scan_roots = [TEMPLATES_DIR, STATIC_DIR, BASE_DIR / "agents"]
    source_files = [BASE_DIR / "app.py", BASE_DIR / "requirements.txt"]
    allowed_suffixes = {".py", ".html", ".js", ".css", ".txt"}
    for root in scan_roots:
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in allowed_suffixes:
                continue
            try:
                path.resolve().relative_to(root.resolve())
            except ValueError:
                continue
            source_files.append(path)

    source_files = list(dict.fromkeys(source_files))[:500]
    contents = {}
    total_bytes = 0
    unreadable = []
    for path in source_files:
        try:
            size = path.stat().st_size
            if size > 2 * 1024 * 1024 or total_bytes + size > 10 * 1024 * 1024:
                unreadable.append(path.name)
                continue
            contents[path.relative_to(BASE_DIR).as_posix()] = path.read_text(
                encoding="utf-8",
                errors="replace",
            )
            total_bytes += size
        except OSError:
            unreadable.append(path.name)

    app_source = contents.get("app.py", "")
    all_source = "\n".join(contents.values())
    templates_source = "\n".join(
        text for name, text in contents.items() if name.startswith("templates/")
    )
    python_source = "\n".join(
        text for name, text in contents.items() if name.endswith(".py")
    )
    requirements = contents.get("requirements.txt", "")
    requirements_lines = [
        line.strip() for line in requirements.splitlines()
        if line.strip() and not line.lstrip().startswith(("#", "-"))
    ]
    unpinned = [line for line in requirements_lines if not re.search(r"(===|==|~=|>=|<=|!=)", line)]
    total_checks = 14

    yield {
        "title": "Инвентаризация файлов проекта",
        "status": "pass" if contents and not unreadable else "warning",
        "severity": "info" if contents and not unreadable else "low",
        "message": f"Просмотрено {len(contents)} файлов кода и конфигурации; суммарный размер {total_bytes // 1024} КБ. Базы данных, .env, виртуальное окружение и загрузки не открывались.",
    }

    configured_secret = os.getenv("SECRET_KEY") or os.getenv("SESSION_SECRET")
    yield {
        "title": "Ключ сессии",
        "status": "pass" if configured_secret and len(configured_secret) >= 32 else "warning",
        "severity": "info" if configured_secret and len(configured_secret) >= 32 else "medium",
        "message": "Используется постоянный ключ достаточной длины." if configured_secret and len(configured_secret) >= 32 else "Постоянный SECRET_KEY/SESSION_SECRET не найден или короче 32 символов; сессии могут сбрасываться после перезапуска.",
    }
    password_ok = "password_hasher" in app_source and "password_hasher.verify" in app_source and "password_hasher.hash" in app_source
    yield {
        "title": "Хранение паролей",
        "status": "pass" if password_ok else "warning",
        "severity": "info" if password_ok else "high",
        "message": "Пароли обрабатываются рекомендованным PasswordHash-хешированием." if password_ok else "Не удалось подтвердить хеширование паролей по коду приложения.",
    }
    session_configured = "SessionMiddleware" in app_source and "same_site=\"lax\"" in app_source
    https_only = os.getenv("COOKIE_SECURE", "0") == "1"
    yield {
        "title": "Настройки cookie-сессии",
        "status": "pass" if session_configured and https_only else "warning",
        "severity": "info" if session_configured and https_only else "low",
        "message": "SessionMiddleware и SameSite настроены; cookie Secure включён." if session_configured and https_only else "SessionMiddleware и SameSite настроены. COOKIE_SECURE выключен; включи его при работе через HTTPS.",
    }
    upload_limited = "10 * 1024 * 1024 + 1" in app_source and "File exceeds 10 MB limit" in app_source
    yield {
        "title": "Ограничение загружаемых файлов",
        "status": "pass" if upload_limited else "warning",
        "severity": "info" if upload_limited else "medium",
        "message": "Загрузка ограничена 10 МБ." if upload_limited else "Лимит размера файла не подтверждён статической проверкой.",
    }
    raw_sql = bool(re.search(r"cursor\.execute\s*\(|execute\s*\(\s*f[\"']|text\s*\(\s*f[\"']", python_source, re.IGNORECASE))
    yield {
        "title": "SQL injection patterns",
        "status": "warning" if raw_sql else "pass",
        "severity": "high" if raw_sql else "info",
        "message": "Найдена конструкция, похожая на сборку SQL из строки; проверь её вручную." if raw_sql else "Опасных шаблонов динамического SQL в просмотренном Python-коде не найдено; ORM-запросы отдельно не эксплуатировались.",
    }
    xss = bool(re.search(r"\binnerHTML\s*=|\|\s*safe\b|Markup\s*\(", all_source, re.IGNORECASE))
    yield {
        "title": "XSS patterns",
        "status": "warning" if xss else "pass",
        "severity": "medium" if xss else "info",
        "message": "Найдено место с небезопасной вставкой HTML; требуется ручная проверка контекста." if xss else "Небезопасные HTML-вставки по проверенным шаблонам не обнаружены.",
    }
    dynamic_exec = False
    for name, text in contents.items():
        if not name.endswith(".py"):
            continue
        try:
            syntax_tree = ast.parse(text)
        except SyntaxError:
            continue
        for node in ast.walk(syntax_tree):
            if not isinstance(node, ast.Call):
                continue
            function = node.func
            if isinstance(function, ast.Name) and function.id in {"eval", "exec"}:
                dynamic_exec = True
                break
            if (isinstance(function, ast.Attribute) and function.attr == "system"
                    and isinstance(function.value, ast.Name) and function.value.id == "os"):
                dynamic_exec = True
                break
            if any(keyword.arg == "shell" and isinstance(keyword.value, ast.Constant)
                   and keyword.value.value is True for keyword in node.keywords):
                dynamic_exec = True
                break
        if dynamic_exec:
            break
    yield {
        "title": "Выполнение кода и команд",
        "status": "warning" if dynamic_exec else "pass",
        "severity": "high" if dynamic_exec else "info",
        "message": "Найден потенциально опасный шаблон выполнения команд или кода." if dynamic_exec else "eval/exec, shell=True и os.system в просмотренном коде не найдены; файлы проекта не запускались.",
    }
    admin_guarded = "Depends(require_admin)" in app_source and "def require_admin" in app_source
    yield {
        "title": "Защита административных маршрутов",
        "status": "pass" if admin_guarded else "warning",
        "severity": "info" if admin_guarded else "high",
        "message": "В приложении есть общая проверка роли для административных операций." if admin_guarded else "Не найдена общая проверка роли администратора.",
    }
    yield {
        "title": "Фиксация зависимостей",
        "status": "warning" if unpinned else "pass",
        "severity": "medium" if unpinned else "info",
        "message": f"Без точных версий указано пакетов: {len(unpinned)}. Проверка не загружает данные из интернета и не сверяет CVE." if unpinned else "Версии прямых зависимостей зафиксированы.",
    }
    agent_auth = "token_hash" in app_source and "hashlib.sha256" in app_source and "ManagedAgent.active.is_(True)" in app_source
    yield {
        "title": "Аутентификация и отзыв агентов",
        "status": "pass" if agent_auth else "warning",
        "severity": "info" if agent_auth else "medium",
        "message": "Ключи агентов проверяются по хешу, отзыв ключа блокирует heartbeat." if agent_auth else "Не удалось подтвердить безопасную проверку и отзыв ключей агентов.",
    }
    passive_osint = "def normalize_osint_target" in app_source and "def dns_lookup" in app_source and "def rdap_lookup" in app_source
    yield {
        "title": "OSINT-интеграции",
        "status": "pass" if passive_osint else "warning",
        "severity": "info" if passive_osint else "medium",
        "message": "Обнаружены только функции нормализации цели, DNS и RDAP; сетевое сканирование не запускалось." if passive_osint else "Не удалось подтвердить ограничения OSINT-проверок по исходному коду.",
    }
    audit_ok = "def log_audit" in app_source and "Scan(" in app_source
    yield {
        "title": "История проверок и audit log",
        "status": "pass" if audit_ok else "warning",
        "severity": "info" if audit_ok else "low",
        "message": "Приложение содержит сохранение результатов и audit log." if audit_ok else "Не удалось подтвердить сохранение истории и событий.",
    }
    yield {
        "title": "Проверка области сканирования",
        "status": "pass",
        "severity": "info",
        "message": f"Проверены локальные файлы проекта, всего шагов: {total_checks}. Внешние сайты и сетевые адреса не запрашивались.",
    }


@app.get("/scan/site", response_class=HTMLResponse)
def site_scan_page(
    request: Request,
    current_user: User = Depends(require_admin),
):
    return templates.TemplateResponse(
        request=request,
        name="site_scan.html",
        context={"request": request, "user": current_user},
    )


@app.post("/api/scan/site")
def scan_site(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    def event_stream():
        checks = []
        yield json.dumps({"type": "start", "total": 14}, ensure_ascii=False) + "\n"
        try:
            for index, check in enumerate(iter_site_audit_checks(), start=1):
                checks.append(check)
                yield json.dumps({"type": "step", "index": index, "total": 14,
                                  "check": check}, ensure_ascii=False) + "\n"

            counts = {
                level: sum(1 for item in checks if item["severity"] == level)
                for level in ("critical", "high", "medium", "low")
            }
            weights = {"critical": 40, "high": 25, "medium": 12, "low": 3}
            risk_score = min(100, sum(counts[level] * weights[level] for level in counts))
            risk_level = next(
                (level for level in ("critical", "high", "medium", "low") if counts[level]),
                "clean",
            )
            findings_count = sum(counts.values())
            summary = {
                "risk_level": risk_level,
                "risk_score": risk_score,
                "checks_total": len(checks),
                "passed": sum(1 for item in checks if item["status"] == "pass"),
                "warnings": findings_count,
                "severity_counts": counts,
            }
            report = {
                "summary": summary,
                "checks": checks,
                "scope": "Local source/configuration review only; no network probing or code execution.",
            }
            scan = Scan(
                filename="SecureWatch local site audit",
                scan_type="site_audit",
                status="completed",
                result=json.dumps(report, ensure_ascii=False),
                findings=findings_count,
                created_by=current_user.id,
            )
            db.add(scan)
            db.commit()
            db.refresh(scan)
            log_audit(db, current_user.id, "site_audit", f"risk={risk_level}; checks={len(checks)}")
            yield json.dumps({"type": "done", "scan_id": scan.id,
                              "summary": summary, "checks": checks}, ensure_ascii=False) + "\n"
        except Exception as exc:
            db.rollback()
            yield json.dumps({"type": "error", "message": f"Проверка прервана ({type(exc).__name__})."}, ensure_ascii=False) + "\n"

    return StreamingResponse(
        event_stream(),
        media_type="application/x-ndjson",
        headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"},
    )


@app.post("/api/scan/file")
async def scan_file(
    file: UploadFile = File(...),
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    allowed_roles = {
        "owner",
        "security_admin",
        "employee",
    }

    if current_user.role not in allowed_roles:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    filename = Path(file.filename or "upload.bin").name

    content = await file.read(10 * 1024 * 1024 + 1)

    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(
            status_code=413,
            detail="File exceeds 10 MB limit",
        )

    result = analyze_file(
        filename,
        content,
    )

    scan = Scan(
        filename=filename,
        scan_type="file",
        status="completed",
        result=json.dumps(result, ensure_ascii=False),
        findings=result["findings_count"],
        created_by=current_user.id,
    )

    db.add(scan)
    db.commit()
    db.refresh(scan)

    log_audit(
        db,
        current_user.id,
        "file_scan",
        filename,
    )

    return {
        "scan_id": scan.id,
        **result,
    }


# ============================================================
# DEPENDENCY SCANNING
# ============================================================

@app.post("/api/scan/dependencies")
def scan_dependencies(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "list",
                "--format=json",
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=True,
        )

        packages = json.loads(result.stdout)

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Dependency scan failed: {type(exc).__name__}",
        )

    report = {
        "packages_count": len(packages),
        "packages": packages,
        "note": (
            "Package inventory only. "
            "This does not establish whether a package is vulnerable."
        ),
    }

    scan = Scan(
        filename="Python dependencies",
        scan_type="dependencies",
        status="completed",
        result=json.dumps(report, ensure_ascii=False),
        findings=0,
        created_by=current_user.id,
    )

    db.add(scan)
    db.commit()
    db.refresh(scan)

    log_audit(
        db,
        current_user.id,
        "dependency_scan",
        f"{len(packages)} packages",
    )

    return {
        "scan_id": scan.id,
        **report,
    }


# ============================================================
# SCAN HISTORY AND DETAILS
# ============================================================

@app.get("/scans")
def scan_history(
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    scans = db.query(Scan).order_by(
        Scan.created_at.desc()
    ).all()

    return [
        {
            "id": scan.id,
            "filename": scan.filename,
            "scan_type": scan.scan_type,
            "status": scan.status,
            "findings": scan.findings,
            "created_at": scan.created_at.isoformat(),
        }
        for scan in scans
    ]


@app.get("/scans/{scan_id}", response_class=HTMLResponse)
def scan_detail(
    scan_id: int,
    request: Request,
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    scan = db.query(Scan).filter(
        Scan.id == scan_id
    ).first()

    if not scan:
        raise HTTPException(
            status_code=404,
            detail="Scan not found",
        )

    try:
        result = json.loads(scan.result or "{}")
    except json.JSONDecodeError:
        result = {}

    return templates.TemplateResponse(
        request=request,
        name="scan_detail.html",
        context={
            "request": request,
            "user": current_user,
            "scan": scan,
            "result": result,
        },
    )


# ============================================================
# OSINT HELPERS
# ============================================================

DOMAIN_PATTERN = re.compile(
    r"(?=^.{1,253}$)"
    r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)"
    r"(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+",
    re.IGNORECASE,
)


def normalize_osint_target(value: str) -> tuple[str, str]:
    value = value.strip()

    if not value:
        raise ValueError("Target is empty")

    if "://" in value or "/" in value or "@" in value:
        raise ValueError("Enter a domain name or IP address, not a URL")

    value = value.rstrip(".").lower()

    try:
        ip_obj = ipaddress.ip_address(value)
    except ValueError:
        ip_obj = None

    if ip_obj is not None:
        if not ip_obj.is_global:
            raise ValueError("Only public IP addresses can be searched")
        return value, "ip"

    if not DOMAIN_PATTERN.fullmatch(value):
        raise ValueError("Enter a valid domain name or IP address")

    return value, "domain"


def get_or_create_node(
    db: Session,
    value: str,
    node_type: str,
    details: Optional[dict] = None,
) -> OSINTNode:

    node = db.query(OSINTNode).filter(
        OSINTNode.value == value,
        OSINTNode.node_type == node_type,
    ).first()

    if node:
        if details:
            node.details = json.dumps(
                details,
                ensure_ascii=False,
            )
        return node

    node = OSINTNode(
        value=value,
        node_type=node_type,
        details=json.dumps(
            details or {},
            ensure_ascii=False,
        ),
    )

    db.add(node)
    db.flush()

    return node


def add_osint_edge(
    db: Session,
    source: OSINTNode,
    target: OSINTNode,
    relationship: str,
    details: Optional[dict] = None,
):
    existing = db.query(OSINTEdge).filter(
        OSINTEdge.source_id == source.id,
        OSINTEdge.target_id == target.id,
        OSINTEdge.relationship == relationship,
    ).first()

    if existing:
        return existing

    edge = OSINTEdge(
        source_id=source.id,
        target_id=target.id,
        relationship=relationship,
        details=json.dumps(
            details or {},
            ensure_ascii=False,
        ),
    )

    db.add(edge)

    return edge


# ============================================================
# PASSIVE DNS LOOKUP
# ============================================================

def dns_lookup(domain: str) -> list[str]:
    addresses = set()

    try:
        results = socket.getaddrinfo(
            domain,
            None,
            proto=socket.IPPROTO_TCP,
        )

        for result in results:
            address = result[4][0]

            try:
                address_obj = ipaddress.ip_address(address)
                if not address_obj.is_global:
                    continue
                addresses.add(address)
            except ValueError:
                continue

    except socket.gaierror:
        pass

    return sorted(addresses)


# ============================================================
# RDAP LOOKUP
# ============================================================

def rdap_lookup(target: str) -> dict:
    """
    Passive registration-data lookup through rdap.org.
    The submitted value is normalized before it is used.
    """

    try:
        ip_obj = ipaddress.ip_address(target)
        endpoint = (
            "https://rdap.org/ip/"
            + urllib.parse.quote(str(ip_obj), safe=":")
        )

    except ValueError:
        endpoint = (
            "https://rdap.org/domain/"
            + urllib.parse.quote(target, safe="")
        )

    request = urllib.request.Request(
        endpoint,
        headers={
            "User-Agent": "SecureWatch/1.0",
            "Accept": "application/rdap+json, application/json",
        },
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=8,
        ) as response:
            data = json.loads(
                response.read(1024 * 1024).decode("utf-8")
            )

        return {
            "status": "success",
            "data": data,
        }

    except urllib.error.HTTPError as exc:
        return {
            "status": "unavailable",
            "error": f"RDAP HTTP {exc.code}",
        }

    except Exception as exc:
        return {
            "status": "unavailable",
            "error": type(exc).__name__,
        }


def refresh_saved_osint_nodes() -> int:
    """Refresh saved public targets using passive DNS and RDAP only."""
    global _osint_refresh_cursor

    db = SessionLocal()
    refreshed = 0
    try:
        query = db.query(OSINTNode).filter(
            OSINTNode.node_type.in_(("domain", "ip")),
            OSINTNode.id > _osint_refresh_cursor,
        ).order_by(OSINTNode.id.asc())
        targets = query.limit(OSINT_REFRESH_BATCH_SIZE).all()

        if not targets:
            _osint_refresh_cursor = 0
            targets = db.query(OSINTNode).filter(
                OSINTNode.node_type.in_(("domain", "ip"))
            ).order_by(OSINTNode.id.asc()).limit(OSINT_REFRESH_BATCH_SIZE).all()

        for node in targets:
            value = node.value
            node_type = node.node_type
            dns_addresses = dns_lookup(value) if node_type == "domain" else []

            for address in dns_addresses:
                ip_node = get_or_create_node(
                    db,
                    address,
                    "ip",
                    {"source": "dns", "domain": value},
                )
                add_osint_edge(db, node, ip_node, "resolves_to")

            rdap = rdap_lookup(value)
            try:
                details = json.loads(node.details or "{}")
            except (TypeError, json.JSONDecodeError):
                details = {}
            details.update({
                "last_refreshed": datetime.utcnow().isoformat(),
                "rdap_status": rdap.get("status"),
                "rdap": rdap,
            })
            if node_type == "domain":
                details["dns"] = dns_addresses
            node.details = json.dumps(details, ensure_ascii=False)
            db.commit()
            _osint_refresh_cursor = node.id
            refreshed += 1
            _osint_refresh_stop.wait(2)

        return refreshed
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def osint_refresh_worker():
    while not _osint_refresh_stop.wait(OSINT_REFRESH_INTERVAL_SECONDS):
        try:
            refresh_saved_osint_nodes()
        except Exception:
            # Keep the service running; the next scheduled cycle can retry.
            continue


def start_osint_refresh_worker():
    global _osint_refresh_thread
    if _osint_refresh_thread and _osint_refresh_thread.is_alive():
        return
    _osint_refresh_stop.clear()
    _osint_refresh_thread = threading.Thread(
        target=osint_refresh_worker,
        name="securewatch-osint-refresh",
        daemon=True,
    )
    _osint_refresh_thread.start()


# ============================================================
# OSINT SEARCH API
# ============================================================

@app.post("/api/osint/search")
def osint_search(
    target: str = Form(...),
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    try:
        normalized, target_type = normalize_osint_target(target)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    root_details = {
        "source": "user_search",
        "searched_at": datetime.utcnow().isoformat(),
    }

    root_node = get_or_create_node(
        db,
        normalized,
        target_type,
        root_details,
    )

    result = {
        "target": normalized,
        "type": target_type,
        "dns": [],
        "rdap": {},
    }

    if target_type == "domain":
        addresses = dns_lookup(normalized)
        result["dns"] = addresses

        for address in addresses:
            ip_node = get_or_create_node(
                db,
                address,
                "ip",
                {
                    "source": "dns",
                    "domain": normalized,
                },
            )

            add_osint_edge(
                db,
                root_node,
                ip_node,
                "resolves_to",
            )

    result["rdap"] = rdap_lookup(normalized)

    root_node.details = json.dumps(
        {
            **root_details,
            "rdap_status": result["rdap"].get("status"),
            "rdap": result["rdap"],
            "dns": result["dns"],
        },
        ensure_ascii=False,
    )

    db.commit()

    log_audit(
        db,
        current_user.id,
        "osint_search",
        normalized,
    )

    return result


# ============================================================
# OSINT GRAPH API
# ============================================================

def clean_agent_ip_list(value) -> list[str]:
    if not isinstance(value, list):
        return []
    result = []
    for raw_ip in value[:16]:
        if not isinstance(raw_ip, str) or len(raw_ip) > 45:
            continue
        try:
            parsed = ipaddress.ip_address(raw_ip)
        except ValueError:
            continue
        if parsed.is_unspecified or parsed.is_multicast:
            continue
        normalized = str(parsed)
        if normalized not in result:
            result.append(normalized)
    return result


async def read_limited_json(request: Request, max_bytes: int) -> dict:
    length = request.headers.get("content-length")
    if length:
        try:
            if int(length) > max_bytes:
                raise HTTPException(status_code=413, detail="Agent report is too large")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid content length")
    chunks = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > max_bytes:
            raise HTTPException(status_code=413, detail="Agent report is too large")
        chunks.append(chunk)
    try:
        payload = json.loads(b"".join(chunks))
    except (ValueError, json.JSONDecodeError):
        raise HTTPException(status_code=400, detail="Invalid JSON")
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid agent report")
    return payload


@app.post("/api/agents/enroll")
async def enroll_agent(request: Request, db: Session = Depends(get_db)):
    payload = await read_limited_json(request, 8192)

    code = payload.get("enrollment_code")
    if not isinstance(code, str) or len(code) > 128:
        raise HTTPException(status_code=400, detail="Invalid enrollment code")
    code_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
    now = datetime.utcnow()
    enrollment = db.query(AgentEnrollment).filter(
        AgentEnrollment.code_hash == code_hash,
        AgentEnrollment.used_at.is_(None),
        AgentEnrollment.expires_at > now,
    ).first()
    if not enrollment:
        raise HTTPException(status_code=401, detail="Enrollment code is invalid or expired")
    creator_id = enrollment.created_by
    claimed = db.query(AgentEnrollment).filter(
        AgentEnrollment.code_hash == code_hash,
        AgentEnrollment.used_at.is_(None),
        AgentEnrollment.expires_at > now,
    ).update({AgentEnrollment.used_at: now}, synchronize_session=False)
    if claimed != 1:
        db.rollback()
        raise HTTPException(status_code=401, detail="Enrollment code is invalid or expired")

    name = payload.get("name") if isinstance(payload.get("name"), str) else ""
    os_name = payload.get("os_name") if isinstance(payload.get("os_name"), str) else ""
    os_version = payload.get("os_version") if isinstance(payload.get("os_version"), str) else ""
    architecture = payload.get("architecture") if isinstance(payload.get("architecture"), str) else ""
    name = re.sub(r"[\x00-\x1f]", "", name).strip()[:100] or "Unnamed agent"
    os_name = re.sub(r"[\x00-\x1f]", "", os_name).strip()[:100] or "Unknown OS"
    os_version = re.sub(r"[\x00-\x1f]", "", os_version).strip()[:200]
    architecture = re.sub(r"[\x00-\x1f]", "", architecture).strip()[:50]

    token = secrets.token_urlsafe(48)
    agent = ManagedAgent(
        id=str(secrets.token_hex(16)),
        name=name,
        os_name=os_name,
        os_version=os_version,
        architecture=architecture,
        local_ips=json.dumps(clean_agent_ip_list(payload.get("local_ips"))),
        remote_ip=(request.client.host if request.client else "unknown")[:45],
        token_hash=hashlib.sha256(token.encode("utf-8")).hexdigest(),
        created_by=creator_id,
        last_seen=now,
    )
    db.add(agent)
    db.commit()
    return {"agent_id": agent.id, "api_token": token, "heartbeat_interval": 60}


@app.post("/api/agents/heartbeat")
async def agent_heartbeat(request: Request, db: Session = Depends(get_db)):
    authorization = request.headers.get("authorization", "")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token or len(token) > 128:
        raise HTTPException(status_code=401, detail="Agent authentication required")
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    agent = db.query(ManagedAgent).filter(
        ManagedAgent.token_hash == token_hash,
        ManagedAgent.active.is_(True),
    ).first()
    if not agent:
        raise HTTPException(status_code=401, detail="Agent token is invalid or revoked")

    payload = await read_limited_json(request, 8192)

    name = payload.get("name") if isinstance(payload.get("name"), str) else agent.name
    os_name = payload.get("os_name") if isinstance(payload.get("os_name"), str) else agent.os_name
    os_version = payload.get("os_version") if isinstance(payload.get("os_version"), str) else agent.os_version
    architecture = payload.get("architecture") if isinstance(payload.get("architecture"), str) else agent.architecture
    agent.name = re.sub(r"[\x00-\x1f]", "", name).strip()[:100] or agent.name
    agent.os_name = re.sub(r"[\x00-\x1f]", "", os_name).strip()[:100] or agent.os_name
    agent.os_version = re.sub(r"[\x00-\x1f]", "", os_version).strip()[:200]
    agent.architecture = re.sub(r"[\x00-\x1f]", "", architecture).strip()[:50]
    agent.local_ips = json.dumps(clean_agent_ip_list(payload.get("local_ips")))
    agent.remote_ip = (request.client.host if request.client else "unknown")[:45]
    agent.last_seen = datetime.utcnow()
    db.commit()
    return {"ok": True, "last_seen": agent.last_seen.isoformat()}

def classify_client(platform: str, user_agent: str) -> tuple[str, str]:
    """Return best-effort browser OS and browser family from client hints."""
    platform = (platform or "").strip().lower()[:100]
    ua = (user_agent or "").lower()
    if "android" in platform or "android" in ua:
        os_name = "Android"
    elif "iphone" in ua or "ipad" in ua or "ios" in platform:
        os_name = "iOS"
    elif "win" in platform or "windows nt" in ua:
        os_name = "Windows"
    elif "mac" in platform or "macintosh" in ua:
        os_name = "macOS"
    elif "cros" in ua or "chrome os" in platform:
        os_name = "ChromeOS"
    elif "linux" in platform or "linux" in ua or "x11" in ua:
        os_name = "Linux (distribution unknown)"
    else:
        os_name = platform[:80] or "Unknown OS"

    if "edg/" in ua:
        browser = "Edge"
    elif "opr/" in ua or "opera" in ua:
        browser = "Opera"
    elif "firefox/" in ua:
        browser = "Firefox"
    elif "chrome/" in ua or "chromium" in ua:
        browser = "Chrome/Chromium"
    elif "safari/" in ua:
        browser = "Safari"
    else:
        browser = "Unknown browser"
    return os_name, browser


@app.post("/api/system/heartbeat")
async def system_heartbeat(
    request: Request,
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    """Record this authenticated browser/API client; no network probing is done."""
    try:
        body = await request.body()
        if len(body) > 4096:
            raise HTTPException(status_code=413, detail="Client report is too large")
        payload = json.loads(body)
    except HTTPException:
        raise
    except (ValueError, json.JSONDecodeError):
        raise HTTPException(status_code=400, detail="Invalid JSON")
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid client report")

    device_id = str(payload.get("device_id", ""))[:64]
    if not re.fullmatch(r"[A-Za-z0-9_-]{16,64}", device_id):
        raise HTTPException(status_code=400, detail="Invalid device id")
    platform = str(payload.get("platform", ""))[:100]
    user_agent = request.headers.get("user-agent", "")[:500]
    os_name, browser = classify_client(platform, user_agent)
    client_ip = request.client.host if request.client else "unknown"

    row = db.query(ConnectedSystem).filter(
        ConnectedSystem.device_id == device_id
    ).first()
    now = datetime.utcnow()
    if row is None:
        row = ConnectedSystem(
            device_id=device_id,
            user_id=current_user.id,
            first_seen=now,
        )
        db.add(row)
    row.user_id = current_user.id
    row.os_name = os_name
    row.browser = browser
    row.ip_address = client_ip[:45]
    row.last_seen = now
    db.commit()
    return {"ok": True, "os": os_name, "browser": browser}


@app.get("/api/system/graph")
def connected_system_graph(
    view: str = "devices",
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Return recently observed clients as a device or IP relationship graph."""
    if view not in {"devices", "ips"}:
        raise HTTPException(status_code=400, detail="Invalid graph view")
    cutoff = datetime.utcnow() - timedelta(days=30)
    systems = db.query(ConnectedSystem).filter(
        ConnectedSystem.last_seen >= cutoff
    ).order_by(ConnectedSystem.last_seen.desc()).limit(500).all()
    agents = db.query(ManagedAgent).filter(
        ManagedAgent.active.is_(True),
        ManagedAgent.last_seen >= cutoff,
    ).order_by(ManagedAgent.last_seen.desc()).limit(500).all()
    nodes = [{"id": "securewatch", "label": "SecureWatch API", "type": "server",
              "details": {"description": "This SecureWatch instance"}}]
    edges = []
    if view == "devices":
        display_count = len(systems) + len(agents)
        for system in systems:
            node_id = f"device:{system.device_id}"
            nodes.append({
                "id": node_id,
                "label": f"{system.os_name} · {system.browser}",
                "type": "device",
                "details": {"os": system.os_name, "browser": system.browser,
                            "ip": system.ip_address, "first_seen": system.first_seen.isoformat(),
                            "last_seen": system.last_seen.isoformat(), "device_id": system.device_id},
            })
            edges.append({"id": f"connection:{system.device_id}", "from": node_id,
                          "to": "securewatch", "label": "connected to SecureWatch"})
        for agent in agents:
            node_id = f"agent:{agent.id}"
            nodes.append({
                "id": node_id,
                "label": f"{agent.name} · {agent.os_name}",
                "type": "agent",
                "details": {"name": agent.name, "os": agent.os_name,
                            "os_version": agent.os_version,
                            "architecture": agent.architecture,
                            "local_ips": json.loads(agent.local_ips or "[]"),
                            "server_observed_ip": agent.remote_ip,
                            "last_seen": agent.last_seen.isoformat()},
            })
            edges.append({"id": f"agent-connection:{agent.id}", "from": node_id,
                          "to": "securewatch", "label": "agent heartbeat"})
    else:
        by_ip = {}
        for system in systems:
            device_id = f"device:{system.device_id}"
            nodes.append({"id": device_id, "label": f"{system.os_name} · {system.browser}",
                          "type": "device", "details": {"os": system.os_name,
                          "browser": system.browser, "last_seen": system.last_seen.isoformat()}})
            edges.append({"id": f"device-connection:{system.device_id}", "from": device_id,
                          "to": "securewatch", "label": "connected to SecureWatch"})
            by_ip.setdefault(system.ip_address, []).append((device_id, system.os_name, system.last_seen))
        for agent in agents:
            agent_id = f"agent:{agent.id}"
            nodes.append({"id": agent_id, "label": f"{agent.name} · {agent.os_name}",
                          "type": "agent", "details": {"os": agent.os_name,
                          "os_version": agent.os_version, "last_seen": agent.last_seen.isoformat()}})
            edges.append({"id": f"agent-connection:{agent.id}", "from": agent_id,
                          "to": "securewatch", "label": "agent heartbeat"})
            candidate_ips = [agent.remote_ip, *json.loads(agent.local_ips or "[]")]
            for ip_address in set(candidate_ips):
                by_ip.setdefault(ip_address, []).append((agent_id, agent.os_name, agent.last_seen))
        display_count = 0
        for ip_address, connected in by_ip.items():
            try:
                ipaddress.ip_address(ip_address)
            except ValueError:
                continue
            display_count += 1
            node_id = f"ip:{ip_address}"
            connected_to = sorted({item[0] for item in connected})
            nodes.append({"id": node_id, "label": ip_address, "type": "ip",
                          "details": {"ip": ip_address, "systems": sorted({item[1] for item in connected}),
                                      "last_seen": max(item[2] for item in connected).isoformat()}})
            for related_id in connected_to:
                edges.append({"id": f"{node_id}:{related_id}", "from": node_id,
                              "to": related_id, "label": "observed address"})
    return {"nodes": nodes, "edges": edges, "view": view,
            "observed_clients": len(systems) + len(agents),
            "display_count": display_count, "window_days": 30}

@app.get("/api/osint/graph")
def osint_graph(
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    nodes = db.query(OSINTNode).all()
    edges = db.query(OSINTEdge).all()

    return {
        "nodes": [
            {
                "id": node.id,
                "label": node.value,
                "type": node.node_type,
                "details": node.details,
            }
            for node in nodes
        ],
        "edges": [
            {
                "id": edge.id,
                "from": edge.source_id,
                "to": edge.target_id,
                "label": edge.relationship,
                "details": edge.details,
            }
            for edge in edges
        ],
    }


@app.get("/api/osint/node/{node_id}")
def osint_node_detail(
    node_id: int,
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    node = db.query(OSINTNode).filter(
        OSINTNode.id == node_id
    ).first()

    if not node:
        raise HTTPException(
            status_code=404,
            detail="OSINT node not found",
        )

    connected_edges = db.query(OSINTEdge).filter(
        (OSINTEdge.source_id == node_id)
        | (OSINTEdge.target_id == node_id)
    ).all()

    related_ids = set()

    for edge in connected_edges:
        related_ids.add(edge.source_id)
        related_ids.add(edge.target_id)

    related_nodes = db.query(OSINTNode).filter(
        OSINTNode.id.in_(related_ids)
    ).all() if related_ids else []

    return {
        "node": {
            "id": node.id,
            "value": node.value,
            "type": node.node_type,
            "details": node.details,
        },
        "related_nodes": [
            {
                "id": item.id,
                "value": item.value,
                "type": item.node_type,
            }
            for item in related_nodes
            if item.id != node.id
        ],
        "relationships": [
            {
                "source_id": edge.source_id,
                "target_id": edge.target_id,
                "type": edge.relationship,
                "details": edge.details,
            }
            for edge in connected_edges
        ],
    }


# ============================================================
# FIX / RECOMMENDATION API
# ============================================================

@app.get("/api/fixes")
def list_fixes(
    current_user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    fixes = db.query(Fix).order_by(
        Fix.created_at.desc()
    ).all()

    return [
        {
            "id": fix.id,
            "title": fix.title,
            "description": fix.description,
            "status": fix.status,
            "created_at": fix.created_at.isoformat(),
        }
        for fix in fixes
    ]


@app.post("/api/fixes")
def create_fix(
    title: str = Form(...),
    description: str = Form(""),
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    fix = Fix(
        title=title.strip(),
        description=description.strip(),
        status="open",
    )

    db.add(fix)
    db.commit()
    db.refresh(fix)

    log_audit(
        db,
        current_user.id,
        "fix_created",
        title,
    )

    return {
        "id": fix.id,
        "title": fix.title,
        "status": fix.status,
    }


@app.post("/api/fixes/{fix_id}/close")
def close_fix(
    fix_id: int,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    fix = db.query(Fix).filter(
        Fix.id == fix_id
    ).first()

    if not fix:
        raise HTTPException(
            status_code=404,
            detail="Fix not found",
        )

    fix.status = "closed"
    db.commit()

    log_audit(
        db,
        current_user.id,
        "fix_closed",
        str(fix_id),
    )

    return {
        "status": "closed",
        "id": fix_id,
    }


# ============================================================
# AUDIT API
# ============================================================

@app.get("/api/audit")
def audit_history(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    records = db.query(Audit).order_by(
        Audit.created_at.desc()
    ).limit(200).all()

    return [
        {
            "id": item.id,
            "user_id": item.user_id,
            "action": item.action,
            "details": item.details,
            "created_at": item.created_at.isoformat(),
        }
        for item in records
    ]


# ============================================================
# APPLICATION STARTUP
# ============================================================

@app.on_event("startup")
def startup_event():
    """
    Creates the initial owner account if no users exist.

    Set these environment variables before first startup:
    SECUREWATCH_ADMIN_USER
    SECUREWATCH_ADMIN_PASSWORD
    """

    db = SessionLocal()

    try:
        user_count = db.query(User).count()

        if user_count == 0:
            admin_username = os.getenv(
                "SECUREWATCH_ADMIN_USER",
                "admin",
            )

            admin_password = os.getenv(
                "SECUREWATCH_ADMIN_PASSWORD",
            )

            generated_password = not admin_password
            if not admin_password:
                admin_password = secrets.token_urlsafe(24)

            admin = User(
                username=admin_username,
                password_hash=hash_password(admin_password),
                role="owner",
                is_active=True,
            )

            db.add(admin)
            db.commit()

            if generated_password:
                print(
                    "\n"
                    "============================================================\n"
                    "SecureWatch initial administrator credentials\n"
                    f"Username: {admin_username}\n"
                    f"Password: {admin_password}\n"
                    "Save this password now. It is shown only when the\n"
                    "initial administrator is created.\n"
                    "============================================================\n",
                    flush=True,
                )
            else:
                print(f"Initial administrator created: {admin_username}", flush=True)

        primary_owner = get_primary_owner(db)
        if primary_owner:
            if primary_owner.role != "owner":
                primary_owner.role = "owner"
            extra_owners = db.query(User).filter(
                User.role == "owner",
                User.id != primary_owner.id,
            ).all()
            for account in extra_owners:
                account.role = "security_admin"
            db.commit()

    finally:
        db.close()
        start_osint_refresh_worker()


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
    )
