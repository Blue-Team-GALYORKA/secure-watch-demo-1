(() => {
  const ruToEn = {
    'Обзор': 'Overview',
    'Пользователи': 'Users',
    'Настройки': 'Settings',
    'Выйти': 'Log out',
    '⚙ Настройки': '⚙ Settings',
    '♙ Пользователи': '♙ Users',
    '⌕ Сканирование': '⌕ Scanning',
    '▤ История': '▤ History',
    '← Назад к обзору': '← Back to overview',
    'SecureWatch · локальный MVP': 'SecureWatch · local MVP',
    'Пользователи и приглашения': 'Users and invitations',
    'Управляйте доступом команды и приглашайте новых участников.': 'Manage team access and invite new members.',
    'Новое приглашение': 'New invitation',
    'Приглашение действует до первого использования и не истекает. Созданный аккаунт сохраняется, пока администратор его не отключит.': 'Invitations do not expire and can be used once. Accounts remain active until an administrator disables them.',
    'Роль участника': 'Member role',
    'Сотрудник': 'Employee',
    'Администратор безопасности': 'Security administrator',
    'Создать приглашение': 'Create invitation',
    'Создаю приглашение…': 'Creating invitation…',
    'Не удалось создать приглашение': 'Could not create invitation',
    'Приглашение создано. Передайте ссылку нужному сотруднику.': 'Invitation created. Share the link with the intended person.',
    'Ссылка для регистрации': 'Registration link',
    'Скопировать ссылку': 'Copy link',
    'Ссылка скопирована.': 'Link copied.',
    'Ссылка выделена. Скопируйте её вручную.': 'Link selected. Copy it manually.',
    'Учетные записи': 'User accounts',
    'Роли определяют доступ к административным функциям SecureWatch.': 'Roles control access to SecureWatch administration.',
    'Активен': 'Active',
    'Отключен': 'Disabled',
    'Email не указан': 'No email provided',
    'Администратор': 'Administrator',
    'Владелец': 'Owner',
    'Сохранить': 'Save',
    'Отключить': 'Disable',
    'Пока нет учетных записей.': 'There are no user accounts yet.',
    'Отключить этого пользователя?': 'Disable this user?',
    'Настройки интерфейса': 'Interface settings',
    'Выбери оформление SecureWatch. Настройка сохранится в этом браузере и будет применяться на остальных страницах.': 'Choose the SecureWatch appearance. This preference is saved in this browser and applies across pages.',
    'Язык': 'Language',
    'Язык интерфейса': 'Interface language',
    'Выбери язык интерфейса.': 'Choose the interface language.',
    'Тема': 'Theme',
    'Выбери светлое или тёмное оформление.': 'Choose a light or dark appearance.',
    'Светлая тема': 'Light theme',
    'Тёмная тема': 'Dark theme',
    'Цветовая тема': 'Color theme',
    'Включена светлая тема.': 'Light theme is enabled.',
    'Включена тёмная тема.': 'Dark theme is enabled.',
    'Назад к обзору': 'Back to overview',
    'PREFERENCES': 'PREFERENCES',
    'Вход в рабочую область': 'Sign in to your workspace',
    'Имя пользователя или email': 'Username or email',
    'Пароль': 'Password',
    'Войти': 'Sign in',
    'Регистрация по приглашению': 'Register with an invitation',
    'Регистрация': 'Registration',
    'Имя пользователя': 'Username',
    'Email (необязательно)': 'Email (optional)',
    'Пароль (минимум 8 символов)': 'Password (at least 8 characters)',
    'Код приглашения (одноразовое, без срока действия)': 'Invitation code (one-time, no expiration)',
    'Создать аккаунт': 'Create account',
    'Введите корректный код приглашения': 'Enter a valid invitation code',
    'Username must have at least 3 characters and password at least 8': 'Username must have at least 3 characters and password at least 8',
    'Username already exists': 'Username already exists',
    'Email already exists': 'Email already exists',
    'Такое имя пользователя или email уже заняты': 'That username or email is already in use',
    'Приглашение недействительно или уже использовано': 'This invitation is invalid or has already been used',
    'Приглашение уже использовано': 'This invitation has already been used',
    'Центр безопасности': 'Security center',
    'Мониторинг, анализ объектов и OSINT-исследования': 'Monitoring, asset analysis, and OSINT research',
    'ВСЕГО ПРОВЕРОК': 'TOTAL SCANS',
    'ЧИСТЫЕ': 'CLEAN',
    'С НАХОДКАМИ': 'WITH FINDINGS',
    'ОШИБКИ': 'ERRORS',
    'Запуск проверок': 'Run checks',
    'Сканировать файлы': 'Scan files',
    'Проверить зависимости': 'Inventory dependencies',
    'Интерактивная карта связей между объектами': 'Interactive map of relationships between objects',
    'Домены': 'Domains',
    'IP-адреса': 'IP addresses',
    'Организации': 'Organizations',
    'Угрозы': 'Threats',
    'Информация об объекте': 'Object details',
    'Выбери точку на графе, чтобы посмотреть информацию.': 'Select a graph node to view its details.',
    'Типы объектов': 'Object types',
    'IP-адрес': 'IP address',
    'Домен': 'Domain',
    'Организация': 'Organization',
    'Угроза': 'Threat',
    'Граф автоматически перечитывает сохранённые результаты раз в 20 секунд. Новый пассивный поиск запускается для введённого IP или домена.': 'The graph reloads saved results every 20 seconds. A passive lookup runs for the IP address or domain you enter.',
    'Исследование публичных IP-адресов и связанных доменов.': 'Look up public IP addresses and related domains.',
    'IP-адрес или домен': 'IP address or domain',
    'Исследовать': 'Look up',
    'Вводи только IP или домен, который разрешено исследовать.': 'Enter only an IP address or domain you are authorized to look up.',
    'Аналитика': 'Analytics',
    'ПРОВЕРКИ ЗА 14 ДНЕЙ': 'SCANS IN THE LAST 14 DAYS',
    'ПРЕДВАРИТЕЛЬНЫЙ УРОВЕНЬ УГРОЗ': 'ESTIMATED THREAT LEVEL',
    'Последние исследования': 'Recent scans',
    'ТИП': 'TYPE',
    'СТАТУС': 'STATUS',
    'ДАТА': 'DATE',
    'РЕЗУЛЬТАТ': 'RESULT',
    'Открыть →': 'Open →',
    'Проверок пока нет.': 'No scans yet.',
    'Сканирование': 'Scanning',
    'История': 'History',
    'Browse Graph': 'Browse Graph',
    'IP Intelligence': 'IP Intelligence',
    'Граф связей OSINT': 'OSINT Relationship Graph',
    'Граф': 'Browse Graph',
    'Графическое представление': 'GRAPH VIEW',
    'Объекты ещё не сохранены. Введите IP-адрес или домен ниже.': 'No saved objects yet. Enter an IP address or domain below.',
    'Типы объектов': 'Object types',
    'Аналитика': 'Analytics',
    'Разведка IP-адресов': 'IP Intelligence',
    'Проверить файл': 'Scan file',
    '⌕ Проверить файл': '⌕ Scan file',
    '◈ Проверить зависимости': '◈ Check dependencies',
    'Файл для проверки': 'File to scan',
    'Выполняю проверку…': 'Scanning…',
    'Не удалось выполнить проверку': 'Scan failed',
    'Проверить сайт целиком': 'Run full site audit',
    'Полная проверка SecureWatch': 'Full SecureWatch audit',
    'Локальный анализ исходников, шаблонов, интерфейса и настроек': 'Local review of source code, templates, UI, and configuration',
    'Подготовка': 'Preparing',
    'Запустить снова': 'Run again',
    'Оценка риска': 'Risk assessment',
    'Ожидание': 'Waiting',
    'Проверка ещё не запущена': 'Audit has not started',
    'Сначала проверю исходный код и настройки проекта.': 'The project source code and configuration will be reviewed first.',
    'ПРОВЕРОК': 'CHECKS',
    'БЕЗ ЗАМЕЧАНИЙ': 'PASSED',
    'ЗАМЕЧАНИЯ': 'WARNINGS',
    'Результаты проверок': 'Audit results',
    'Результаты появятся по мере выполнения проверок.': 'Results will appear as checks run.',
    'Проверяются файлы SecureWatch локально. Сканер не обращается к внешним сайтам, не запускает код проекта и не читает .env, базу данных или загруженные файлы. Это статический аудит по правилам, он не заменяет ручную проверку и тестирование зависимостей на CVE.': 'SecureWatch files are reviewed locally. The scanner does not contact external sites, execute project code, or read .env, the database, or uploaded files. This is a rule-based static audit; it does not replace manual review or CVE checks for dependencies.',
    'Открыть сохранённый отчёт': 'Open saved report',
    'Выполняется': 'Running',
    'Проверка выполняется': 'Audit in progress',
    'Выполняю локальные проверки исходного кода.': 'Running local source checks.',
    'Готово': 'Complete',
    'Ошибка': 'Error',
    'Низкий риск': 'Low risk',
    'Есть замечания': 'Warnings found',
    'Высокий риск': 'High risk',
    'Критический риск': 'Critical risk',
    'Опасные шаблоны не найдены': 'No dangerous patterns found',
    'Инвентаризация файлов проекта': 'Project file inventory',
    'Ключ сессии': 'Session key',
    'Хранение паролей': 'Password storage',
    'Настройки cookie-сессии': 'Session cookie settings',
    'Ограничение загружаемых файлов': 'Upload size limit',
    'SQL injection patterns': 'SQL injection patterns',
    'XSS patterns': 'XSS patterns',
    'Выполнение кода и команд': 'Code and command execution',
    'Защита административных маршрутов': 'Administrative route protection',
    'Фиксация зависимостей': 'Dependency version pinning',
    'Аутентификация и отзыв агентов': 'Agent authentication and revocation',
    'OSINT-интеграции': 'OSINT integrations',
    'История проверок и audit log': 'Scan history and audit log',
    'Проверка области сканирования': 'Audit scope',
    'Начинаю локальную проверку SecureWatch': 'Starting local SecureWatch audit',
    'Проверка завершена; отчёт сохранён в истории.': 'Audit complete; the report was saved to history.',
    'Уровень:': 'Risk level:',
    'Постоянный ключ достаточной длины': 'A persistent key of sufficient length is configured.',
    'Используется постоянный ключ достаточной длины.': 'A persistent key of sufficient length is configured.',
    'Постоянный SECRET_KEY/SESSION_SECRET не найден или короче 32 символов; сессии могут сбрасываться после перезапуска.': 'A persistent SECRET_KEY/SESSION_SECRET was not found or is shorter than 32 characters; sessions may reset after restart.',
    'SessionMiddleware и SameSite настроены. COOKIE_SECURE выключен; включи его при работе через HTTPS.': 'SessionMiddleware and SameSite are configured. COOKIE_SECURE is off; enable it when serving over HTTPS.',
    'КРИТИЧЕСКИЙ': 'CRITICAL',
    'ВЫСОКИЙ': 'HIGH',
    'СРЕДНИЙ': 'MEDIUM',
    'НИЗКИЙ': 'LOW',
    'ИНФО': 'INFO',
    'Пароли обрабатываются рекомендованным PasswordHash-хешированием.': 'Passwords use the recommended PasswordHash hashing.',
    'Загрузка ограничена 10 МБ.': 'Uploads are limited to 10 MB.',
    'Опасных шаблонов динамического SQL в просмотренном Python-коде не найдено; ORM-запросы отдельно не эксплуатировались.': 'No unsafe dynamic SQL patterns were found in the reviewed Python code; ORM queries were not actively tested.',
    'Небезопасные HTML-вставки по проверенным шаблонам не обнаружены.': 'No unsafe HTML insertion patterns were found.',
    'eval/exec, shell=True и os.system в просмотренном коде не найдены; файлы проекта не запускались.': 'No eval/exec, shell=True, or os.system calls were found; project files were not executed.',
    'В приложении есть общая проверка роли для административных операций.': 'The app has a shared role check for administrative operations.',
    'Ключи агентов проверяются по хешу, отзыв ключа блокирует heartbeat.': 'Agent keys are checked by hash; revoking a key blocks heartbeats.',
    'Обнаружены только функции нормализации цели, DNS и RDAP; сетевое сканирование не запускалось.': 'Only target normalization, DNS, and RDAP functions were found; no network scan was run.',
    'Приложение содержит сохранение результатов и audit log.': 'The app saves scan results and audit log events.',
    'Подключённые системы': 'Connected systems',
    'Подключения': 'Connections',
    'Устройства и IP-адреса, которые обращались к SecureWatch за последние 30 дней.': 'Devices and IP addresses that contacted SecureWatch in the last 30 days.',
    'МОНИТОРИНГ API': 'API MONITORING',
    'Представление подключений': 'Connection view',
    'Устройства и ОС': 'Devices and operating systems',
    'IP-адреса систем': 'System IP addresses',
    'Ожидаю подключения устройств к SecureWatch…': 'Waiting for devices to connect to SecureWatch…',
    'Сведения об узле': 'Node details',
    'Нажми на узел графа, чтобы увидеть ОС, IP и время последнего подключения.': 'Select a graph node to view its OS, IP, and last connection time.',
    'Активность за последние 30 дней': 'Activity in the last 30 days',
    'Данные появляются, когда устройство открывает SecureWatch в браузере или отправляет авторизованный запрос к API. Браузер сообщает только семейство ОС; дистрибутивы Linux (например, Kali и Ubuntu) без установленного агента различить нельзя. Автоматическое сканирование сети не выполняется.': 'Data appears when a device opens SecureWatch in a browser or sends an authenticated API request. Browsers report only the OS family; Linux distributions such as Kali and Ubuntu cannot be distinguished without an installed agent. No network scanning is performed.',
    'Не удалось загрузить подключения. Проверь права администратора.': 'Could not load connections. Check administrator access.',
    'Агенты': 'Agents',
    'УПРАВЛЕНИЕ АГЕНТАМИ': 'ENDPOINT MANAGEMENT',
    'Подключай собственные Windows и Linux системы для учёта ОС, IP-адресов и времени активности.': 'Connect your Windows and Linux systems to report OS, IP addresses, and activity.',
    'Подключить агент': 'Connect an agent',
    'Создай одноразовый код регистрации. Он действует 24 часа. После подключения секрет агента будет показан один раз и сохранится на устройстве.': 'Create a one-time enrollment code valid for 24 hours. After enrollment, the agent secret is shown once and saved on the device.',
    'Создать код подключения': 'Create enrollment code',
    'Создаю одноразовый код…': 'Creating one-time code…',
    'Код действует 24 часа и будет принят только один раз.': 'The code is valid for 24 hours and can be used once.',
    'Не удалось создать код': 'Could not create code',
    'Одноразовый код': 'One-time code',
    'Скопируй файл': 'Copy the file',
    ' на целевой компьютер. Затем запусти одну из команд:': ' to the target computer, then run one of these commands:',
    'IP сервера:': 'Server IP:',
    'Последний сигнал:': 'Last heartbeat:',
    'Windows PowerShell': 'Windows PowerShell',
    'Linux': 'Linux',
    'Агент отправляет только системную информацию и heartbeat. Используй HTTPS при подключении через интернет.': 'The agent sends only system inventory and heartbeats. Use HTTPS for internet connections.',
    'URL сервера должен быть доступен целевому компьютеру: localhost и 127.0.0.1 указывают на сам целевой компьютер. Агент отправляет только системную информацию и heartbeat. Для подключения через интернет используй HTTPS.': 'The server URL must be reachable from the target computer; localhost and 127.0.0.1 refer to the target itself. The agent sends only system inventory and heartbeats. Use HTTPS over the internet.',
    'Зарегистрированные агенты': 'Registered agents',
    'Отзыв доступа немедленно блокирует следующие heartbeat этого агента.': 'Revoking access immediately blocks the agent’s next heartbeat.',
    'Агенты ещё не подключены.': 'No agents connected yet.',
    'Доступ отозван': 'Access revoked',
    'Отозвать': 'Revoke',
    'Отозвать доступ этого агента?': 'Revoke this agent’s access?',
    'Данные появляются, когда устройство открывает SecureWatch в браузере или подключённый агент отправляет heartbeat. Агент сообщает точное имя ОС и локальные IP-адреса; браузер определяет только семейство ОС. Автоматическое сканирование сети и выполнение команд не выполняются.': 'Data appears when a device opens SecureWatch in a browser or a connected agent sends a heartbeat. Agents report the OS name and local IP addresses; browsers report only the OS family. No network scanning or command execution is performed.',
    'Основной аккаунт владельца скрыт из списка и защищён от отключения.': 'The primary owner account is hidden from this list and protected from being disabled.',
    'Сервис активен': 'Service active',
    'Система активна': 'System active',
    'Назад к обзору': 'Back to overview',
    'Результат проверки': 'Scan result',
    'Результат': 'Result',
    'находок': 'findings',
    'completed': 'Completed',
    'error': 'Error',
    'open': 'Open',
    'closed': 'Closed',
    'pending': 'Pending',
    'approved': 'Approved',
    'rejected': 'Rejected',
    'Сохранённых объектов пока нет. Введите IP или домен ниже.': 'No saved objects yet. Enter an IP address or domain below.',
    'Не загрузилась библиотека графа. Обновите страницу и попробуйте ещё раз.': 'The graph library did not load. Refresh the page and try again.',
    'Не удалось загрузить сохранённые OSINT-данные.': 'Could not load saved OSINT data.',
    'Не удалось загрузить сведения об объекте.': 'Could not load object details.',
    'Получаю DNS и регистрационные данные…': 'Fetching DNS and registration data…',
    'Не удалось выполнить пассивный поиск.': 'Passive lookup failed.',
    'Введите IP или домен, не URL': 'Enter an IP address or domain, not a URL',
    'Only public IP addresses can be searched': 'Only public IP addresses can be searched',
    'Enter a valid domain name or IP address': 'Enter a valid domain name or IP address',
    'Invalid username or password': 'Invalid username or password',
    'clean': 'clean',
    'high': 'high',
    'medium': 'medium',
    'low': 'low',
    'owner': 'owner',
    'security_admin': 'security admin',
    'employee': 'employee'
  };

  const enToRu = Object.fromEntries(Object.entries(ruToEn).map(([ru, en]) => [en, ru]));
  const controls = [...document.querySelectorAll('[data-language-choice]')];

  function translate(value, language) {
    const trimmed = value.trim();
    let replacement = language === 'en' ? ruToEn[trimmed] : enToRu[trimmed];
    if (!replacement && language === 'en') {
      const inventory = trimmed.match(/^Просмотрено (\d+) файлов кода и конфигурации; суммарный размер (\d+) КБ\. Базы данных, \.env, виртуальное окружение и загрузки не открывались\.$/);
      if (inventory) replacement = `Reviewed ${inventory[1]} source/configuration files (${inventory[2]} KB). Database, .env, virtual environment, and uploads were not opened.`;
      const packages = trimmed.match(/^Без точных версий указано пакетов: (\d+)\. Проверка не загружает данные из интернета и не сверяет CVE\.$/);
      if (packages) replacement = `${packages[1]} dependencies are not pinned. This check does not access the internet or check CVEs.`;
      const scope = trimmed.match(/^Проверены локальные файлы проекта, всего шагов: (\d+)\. Внешние сайты и сетевые адреса не запрашивались\.$/);
      if (scope) replacement = `Reviewed local project files in ${scope[1]} checks. No external sites or network addresses were contacted.`;
      const count = trimmed.match(/^(\d+) аккаунтов?$/);
      if (count) replacement = `${count[1]} accounts`;
      const saved = trimmed.match(/^Сохранённых объектов: (\d+)\. Обновлено (.+)$/);
      if (saved) replacement = `Saved objects: ${saved[1]}. Updated ${saved[2]}`;
      const found = trimmed.match(/^(.+): найдено IP-адресов по DNS — (\d+); RDAP — (.+)\.$/);
      if (found) replacement = `${found[1]}: DNS IP addresses found — ${found[2]}; RDAP — ${found[3]}.`;
      const role = trimmed.match(/^Роль пользователя (.+)$/);
      if (role) replacement = `Role for user ${role[1]}`;
      const roleLabel = trimmed.match(/^Тип: (.+)$/);
      if (roleLabel) replacement = `Type: ${roleLabel[1]}`;
      const userHeader = trimmed.match(/^(.+) · (owner|security_admin|employee)$/);
      if (userHeader) replacement = `${userHeader[1]} · ${ruToEn[userHeader[2]]}`;
    }
    if (!replacement && language === 'ru') {
      const count = trimmed.match(/^(\d+) accounts$/);
      if (count) replacement = `${count[1]} аккаунтов`;
      const saved = trimmed.match(/^Saved objects: (\d+)\. Updated (.+)$/);
      if (saved) replacement = `Сохранённых объектов: ${saved[1]}. Обновлено ${saved[2]}`;
      const found = trimmed.match(/^(.+): DNS IP addresses found — (\d+); RDAP — (.+)\.$/);
      if (found) replacement = `${found[1]}: найдено IP-адресов по DNS — ${found[2]}; RDAP — ${found[3]}.`;
      const role = trimmed.match(/^Role for user (.+)$/);
      if (role) replacement = `Роль пользователя ${role[1]}`;
      const roleLabel = trimmed.match(/^Type: (.+)$/);
      if (roleLabel) replacement = `Тип: ${roleLabel[1]}`;
      const userHeader = trimmed.match(/^(.+) · (owner|security admin|employee)$/);
      if (userHeader) replacement = `${userHeader[1]} · ${enToRu[userHeader[2]] || userHeader[2]}`;
    }
    if (!replacement || replacement === trimmed) return value;
    const start = value.match(/^\s*/)[0];
    const end = value.match(/\s*$/)[0];
    return `${start}${replacement}${end}`;
  }

  window.securewatchTranslate = (value, language) =>
    translate(String(value), language || (document.documentElement.dataset.language === 'en' ? 'en' : 'ru'));

  function translateNode(node, language) {
    if (node.nodeType === Node.TEXT_NODE) {
      const next = translate(node.data, language);
      if (next !== node.data) node.data = next;
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    for (const attr of ['placeholder', 'title', 'aria-label']) {
      if (node.hasAttribute(attr)) {
        const next = translate(node.getAttribute(attr), language);
        if (next !== node.getAttribute(attr)) node.setAttribute(attr, next);
      }
    }
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    textNodes.forEach((textNode) => translateNode(textNode, language));
  }

  function applyLanguage(language, persist = true) {
    if (language !== 'en' && language !== 'ru') return;
    document.documentElement.lang = language;
    document.documentElement.dataset.language = language;
    if (persist) {
      try { localStorage.setItem('securewatch-language', language); } catch (_) {}
    }
    controls.forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.languageChoice === language)));
    translateNode(document.body, language);
    window.dispatchEvent(new CustomEvent('securewatch-language-changed', {detail: {language}}));
  }

  controls.forEach((button) => {
    button.addEventListener('click', () => applyLanguage(button.dataset.languageChoice));
  });

  const language = document.documentElement.dataset.language === 'en' ? 'en' : 'ru';
  applyLanguage(language, false);

  const observer = new MutationObserver((mutations) => {
    const current = document.documentElement.dataset.language === 'en' ? 'en' : 'ru';
    for (const mutation of mutations) {
      if (mutation.type === 'characterData') translateNode(mutation.target, current);
      else mutation.addedNodes.forEach((node) => translateNode(node, current));
    }
  });
  observer.observe(document.body, {subtree: true, childList: true, characterData: true});
})();
