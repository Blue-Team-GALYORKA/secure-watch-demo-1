(() => {
  const container = document.getElementById("osintGraph");
  const detailsPanel = document.getElementById("nodeDetails");
  const status = document.getElementById("graphStatus");
  const form = document.getElementById("ipSearchForm");
  const searchMessage = document.getElementById("ipSearchMessage");
  const viewButtons = [...document.querySelectorAll("[data-connection-view]")];
  if (!container) return;
  if (typeof vis === "undefined") {
    if (status) status.textContent = "Не загрузилась библиотека графа. Обновите страницу и попробуйте ещё раз.";
    return;
  }

  const colors = {
    server: "#e74c3c",
    device: "#3498db",
    agent: "#a855f7",
    ip: "#27ae60"
  };
  const nodes = new vis.DataSet([]);
  const edges = new vis.DataSet([]);
  const network = new vis.Network(container, {nodes, edges}, {
    autoResize: true,
    height: "100%",
    physics: {stabilization: {iterations: 150}},
    interaction: {hover: true, navigationButtons: true, keyboard: true},
    nodes: {borderWidth: 2, shape: "dot", size: 19, font: {color: "#ffffff", size: 13}},
    edges: {width: 1, arrows: {to: {enabled: true, scaleFactor: 0.5}},
      color: {color: "#64748b", highlight: "#38bdf8"},
      font: {color: "#94a3b8", size: 10, align: "middle"},
      smooth: {type: "dynamic"}}
  });

  let refreshing = false;
  let refreshQueued = false;

  function parseDetails(value) {
    if (typeof value !== "string") return value || {};
    try { return JSON.parse(value); } catch (_) { return {raw: value}; }
  }

  let activeView = "devices";

  function setDetails(title, type, data) {
    detailsPanel.replaceChildren();
    const heading = document.createElement("strong");
    heading.textContent = title;
    const typeLine = document.createElement("p");
    typeLine.textContent = `Тип: ${type}`;
    const payload = document.createElement("pre");
    payload.textContent = JSON.stringify(data || {}, null, 2);
    payload.style.cssText = "max-height:260px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;color:inherit";
    detailsPanel.append(heading, typeLine, payload);
  }

  async function loadNodeDetails(id) {
    const node = nodes.get(id);
    if (node) setDetails(node.label, node.group, parseDetails(node.details));
  }

  async function refreshGraph() {
    if (document.hidden) return;
    if (refreshing) {
      refreshQueued = true;
      return;
    }
    refreshing = true;
    try {
      const response = await fetch(`/api/system/graph?view=${encodeURIComponent(activeView)}`, {cache: "no-store"});
      if (!response.ok) throw new Error("Не удалось загрузить подключения. Проверь права администратора.");
      const graph = await response.json();
      const nodeRows = (graph.nodes || []).map((node) => ({
        id: node.id,
        label: node.label,
        group: node.type,
        details: node.details || {},
        color: {background: colors[node.type] || "#64748b", border: "#dce4ed",
          highlight: {background: "#5dade2", border: "#ffffff"}},
        font: {color: "#ffffff", size: 13},
        shape: "dot",
        size: 19
      }));
      const edgeRows = (graph.edges || []).map((edge) => ({
        id: edge.id,
        from: edge.from,
        to: edge.to,
        label: edge.label,
        title: edge.label || "",
        color: {color: "#64748b", highlight: "#38bdf8"},
        font: {color: "#94a3b8", size: 10, align: "middle"},
        smooth: {type: "dynamic"}
      }));
      const nodeIds = new Set(nodeRows.map((node) => node.id));
      const edgeIds = new Set(edgeRows.map((edge) => edge.id));
      nodes.remove(nodes.getIds().filter((id) => !nodeIds.has(id)));
      edges.remove(edges.getIds().filter((id) => !edgeIds.has(id)));
      nodes.update(nodeRows);
      edges.update(edgeRows);
      const english = document.documentElement.dataset.language === "en";
      status.textContent = graph.observed_clients
        ? english
          ? `${graph.observed_clients} clients in 30 days · ${graph.display_count} ${activeView === "devices" ? "devices" : "IP addresses"} · updated ${new Date().toLocaleTimeString()}`
          : `${graph.observed_clients} подключений за 30 дней · ${graph.display_count} ${activeView === "devices" ? "устройств" : "IP-адресов"} · обновлено ${new Date().toLocaleTimeString()}`
        : english
          ? "No systems reported yet. Open SecureWatch in a browser or connect an agent."
          : "Пока нет систем. Открой SecureWatch в браузере или подключи агент.";
    } catch (error) {
      status.textContent = error.message;
    } finally {
      refreshing = false;
      if (refreshQueued) {
        refreshQueued = false;
        refreshGraph();
      }
    }
  }

  network.on("click", (event) => {
    if (event.nodes.length) loadNodeDetails(event.nodes[0]);
  });

  viewButtons.forEach((button) => {
    button.addEventListener("click", () => {
      activeView = button.dataset.connectionView;
      viewButtons.forEach((item) => {
        const selected = item === button;
        item.setAttribute("aria-selected", String(selected));
        item.classList.toggle("secondary", !selected);
      });
      refreshGraph();
    });
  });

  window.addEventListener("securewatch-theme-changed", (event) => {
    const color = event.detail?.theme === "light" ? "#475569" : "#94a3b8";
    edges.update(edges.get().map((edge) => ({
      id: edge.id,
      font: {color, size: 10, align: "middle"}
    })));
    network.redraw();
  });
  window.addEventListener("securewatch-language-changed", refreshGraph);

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const target = document.getElementById("ipTarget").value.trim();
    const button = form.querySelector("button[type=submit], button:not([type])");
    if (!target) return;
    if (button) button.disabled = true;
    searchMessage.textContent = "Получаю DNS и регистрационные данные…";
    try {
      const response = await fetch("/api/osint/search", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: new URLSearchParams({target}),
        credentials: "same-origin"
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "Не удалось выполнить пассивный поиск.");
      searchMessage.textContent = `${data.target}: найдено IP-адресов по DNS — ${data.dns.length}; RDAP — ${data.rdap.status || "недоступен"}.`;
      await refreshGraph();
    } catch (error) {
      searchMessage.textContent = error.message;
    } finally {
      if (button) button.disabled = false;
    }
  });

  refreshGraph();
  window.setInterval(refreshGraph, 20000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) refreshGraph();
  });
})();
