(() => {
  let deviceId;
  try {
    deviceId = localStorage.getItem("securewatch-device-id");
    if (!deviceId) {
      deviceId = globalThis.crypto?.randomUUID?.()
        || Array.from({length: 32}, () => Math.floor(Math.random() * 16).toString(16)).join("");
      localStorage.setItem("securewatch-device-id", deviceId);
    }
  } catch (_) {
    deviceId = Array.from({length: 32}, () => Math.floor(Math.random() * 16).toString(16)).join("");
  }

  async function report() {
    if (document.visibilityState === "hidden") return;
    try {
      await fetch("/api/system/heartbeat", {
        method: "POST",
        credentials: "same-origin",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
          device_id: deviceId,
          platform: navigator.userAgentData?.platform || navigator.platform || ""
        }),
        keepalive: true
      });
    } catch (_) {
      // The graph stays available when telemetry is temporarily offline.
    }
  }

  report();
  window.setInterval(report, 60_000);
  document.addEventListener("visibilitychange", report);
})();
