# SecureWatch MVP

## Запуск на Windows

```powershell
py -3.13 -m venv .venv
Copy-Item .env.example .env
# Укажите в .env собственный SECRET_KEY. Если оставить пароль пустым,
# SecureWatch создаст случайный пароль администратора и выведет его в консоль.
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8000
```

Откройте http://127.0.0.1:8000.

## Linux: Ubuntu и Kali Linux

Нужен Python 3.10 или новее. Пример установки системных пакетов:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
```

Из каталога проекта подготовьте окружение и `.env`:

```bash
python3 -m venv .venv
cp .env.example .env
mkdir -p data
```

Сгенерируйте ключ сессии и укажите его в `SECRET_KEY` в `.env`:

```bash
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

В `.env` укажите полученный ключ и имя администратора в `SECUREWATCH_ADMIN_USER`. Оставьте `SECUREWATCH_ADMIN_PASSWORD` пустым: SecureWatch создаст случайный пароль при первом запуске. Затем установите зависимости и запустите приложение:

```bash
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

Откройте http://127.0.0.1:8000. В `.env.example` база настроена на `data/securewatch.db`; каталог должен быть доступен для записи пользователю приложения. Для доступа из других машин настройте TLS reverse proxy; не публикуйте приложение в интернет напрямую. При работе за HTTPS proxy установите `COOKIE_SECURE=1`.

## Docker Compose на Ubuntu/Kali

Установите Docker Engine и Compose plugin по официальной инструкции для вашего дистрибутива. В каталоге проекта:

```bash
cp .env.example .env
mkdir -p data
sudo chown 10001:10001 data
```

Укажите в `.env` уникальный `SECRET_KEY` и имя `SECUREWATCH_ADMIN_USER`. Оставьте `SECUREWATCH_ADMIN_PASSWORD` пустым для генерации случайного пароля при первом запуске, затем выполните:

```bash
docker compose up --build -d
docker compose logs --tail=100 securewatch
```

При первом запуске пароль будет выведен в лог контейнера. Сохрани его в менеджере паролей: он показывается только при создании начального аккаунта. Веб-интерфейс доступен локально по http://127.0.0.1:8000. SQLite сохраняется в `./data/securewatch.db`. Каталог `data/` должен быть доступен для записи UID 10001 контейнера. Для остановки выполните `docker compose down`; данные в `data/` сохраняются.

Для доступа через reverse proxy включите HTTPS и задайте `COOKIE_SECURE=1` в `.env`. Compose привязывает порт к loopback, поэтому внешний доступ следует организовать через прокси с TLS и ограничением доступа.

## Возможности и ограничения

В приложении есть вход, роли, приглашения, пользователи, журнал аудита, локальный аудит исходников, проверка зависимостей через pip-audit и анализ загруженных файлов. На Windows проверка файла пытается использовать Microsoft Defender; на Linux этот движок недоступен и остаются локальные эвристические проверки. Установка ClamAV сама по себе не подключает его к приложению.

Это учебный MVP, не production-ready. Сканер не запускает загруженные файлы и может пропускать угрозы или давать ложные срабатывания. Проверка зависимостей требует доступа в интернет. Перед внешним развёртыванием настройте TLS, секреты, резервное копирование базы и системное обновление.
